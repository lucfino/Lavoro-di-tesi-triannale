/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class EResidenzialeDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression ID;
	public final IntegerExpression superficie;
	public final IntegerExpression prezzo;
	public final IntegerExpression camere;
	public final StringExpression stato;
	public final IntegerExpression locali;
	public final IntegerExpression piano;
	public final IntegerExpression totale_piani;
	public final BooleanExpression ascensore;
	public final StringExpression classe_energetica;
	public final StringExpression riscaldamento;
	public final StringExpression cucina;
	public final BooleanExpression garage;
	public final IntegerExpression bagni;
	public final StringExpression giardino;
	public final StringExpression balcone;
	
	public EResidenzialeDetachedCriteria() {
		super(com.agenzia.immobiliare.client.entity.EResidenziale.class, com.agenzia.immobiliare.client.entity.EResidenzialeCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		superficie = new IntegerExpression("superficie", this.getDetachedCriteria());
		prezzo = new IntegerExpression("prezzo", this.getDetachedCriteria());
		camere = new IntegerExpression("camere", this.getDetachedCriteria());
		stato = new StringExpression("stato", this.getDetachedCriteria());
		locali = new IntegerExpression("locali", this.getDetachedCriteria());
		piano = new IntegerExpression("piano", this.getDetachedCriteria());
		totale_piani = new IntegerExpression("totale_piani", this.getDetachedCriteria());
		ascensore = new BooleanExpression("ascensore", this.getDetachedCriteria());
		classe_energetica = new StringExpression("classe_energetica", this.getDetachedCriteria());
		riscaldamento = new StringExpression("riscaldamento", this.getDetachedCriteria());
		cucina = new StringExpression("cucina", this.getDetachedCriteria());
		garage = new BooleanExpression("garage", this.getDetachedCriteria());
		bagni = new IntegerExpression("bagni", this.getDetachedCriteria());
		giardino = new StringExpression("giardino", this.getDetachedCriteria());
		balcone = new StringExpression("balcone", this.getDetachedCriteria());
	}
	
	public EResidenzialeDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, com.agenzia.immobiliare.client.entity.EResidenzialeCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		superficie = new IntegerExpression("superficie", this.getDetachedCriteria());
		prezzo = new IntegerExpression("prezzo", this.getDetachedCriteria());
		camere = new IntegerExpression("camere", this.getDetachedCriteria());
		stato = new StringExpression("stato", this.getDetachedCriteria());
		locali = new IntegerExpression("locali", this.getDetachedCriteria());
		piano = new IntegerExpression("piano", this.getDetachedCriteria());
		totale_piani = new IntegerExpression("totale_piani", this.getDetachedCriteria());
		ascensore = new BooleanExpression("ascensore", this.getDetachedCriteria());
		classe_energetica = new StringExpression("classe_energetica", this.getDetachedCriteria());
		riscaldamento = new StringExpression("riscaldamento", this.getDetachedCriteria());
		cucina = new StringExpression("cucina", this.getDetachedCriteria());
		garage = new BooleanExpression("garage", this.getDetachedCriteria());
		bagni = new IntegerExpression("bagni", this.getDetachedCriteria());
		giardino = new StringExpression("giardino", this.getDetachedCriteria());
		balcone = new StringExpression("balcone", this.getDetachedCriteria());
	}
	
	public EIndirizzoDetachedCriteria createEIndirizzoCriteria() {
		return new EIndirizzoDetachedCriteria(createCriteria("eIndirizzo"));
	}
	
	public EResidenziale uniqueEResidenziale(PersistentSession session) {
		return (EResidenziale) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public EResidenziale[] listEResidenziale(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (EResidenziale[]) list.toArray(new EResidenziale[list.size()]);
	}
}

