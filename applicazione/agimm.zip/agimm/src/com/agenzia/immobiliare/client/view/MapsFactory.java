package com.agenzia.immobiliare.client.view;

import com.agenzia.immobiliare.client.Utility;
import com.agenzia.immobiliare.client.UtilityAsync;
import com.agenzia.immobiliare.shared.Config;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;

public class MapsFactory {
	
	UtilityAsync ua = GWT.create(Utility.class);
	
	private static MapsFactory mapsFactory = null;
	
	private IVMapsAdapter mapsAdapter = null;
	
	private MapsFactory(){}
	
	public static MapsFactory getMapsFactory(){
		if (mapsFactory == null){
			mapsFactory = new MapsFactory();
		}
		return mapsFactory;
	}
	
	public IVMapsAdapter getMapsAdapter(){
		if (mapsAdapter == null){
			Config config = Config.getConfig();
			String classe = config.getMaps();
			ua.carica("VMapsAdapter", new AsyncCallback<IVMapsAdapter>(){

				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void onSuccess(IVMapsAdapter result) {
					mapsAdapter = result;
					
				}
				
			});
		}
		return mapsAdapter;
		
	}

}
