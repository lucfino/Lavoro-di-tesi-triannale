/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public abstract class ECommerciale extends com.agenzia.immobiliare.client.entity.EImmobile implements Serializable {
	public ECommerciale() {
	}
	
	public ECommerciale(EIndirizzo ind, int sup, int pre){
		super(ind, sup, pre);
	}
	
	public String toString() {
		return super.toString();
	}
	
}
