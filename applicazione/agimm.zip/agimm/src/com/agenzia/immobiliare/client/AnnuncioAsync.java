package com.agenzia.immobiliare.client;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface AnnuncioAsync{
	
	void carica(int id, AsyncCallback<EAnnuncio> callback);
	
	void inserisciGarage(EAnnuncio ann, AsyncCallback<Boolean> callback);
	
	void cancella(int id, AsyncCallback<Boolean> callback);
	
	void cercaTerreni(String reg, String pro, String cit, int prea, int preda, int supa, int supda, String prop, String col, AsyncCallback<LinkedList<EAnnuncio>> callback);
	
	void cercaGarage(String reg, String pro, String cit, int prea, int preda, int supa, int supda, int gar, AsyncCallback<LinkedList<EAnnuncio>> callback);

	void cerca(AsyncCallback<LinkedList<EAnnuncio>> callback);

	void inserisciTerreni(EAnnuncio ann, AsyncCallback<Boolean> callback);

}
