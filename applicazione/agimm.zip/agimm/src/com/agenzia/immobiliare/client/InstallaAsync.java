package com.agenzia.immobiliare.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface InstallaAsync{

	void installa(String[] config, AsyncCallback<String> callback);
	
}
