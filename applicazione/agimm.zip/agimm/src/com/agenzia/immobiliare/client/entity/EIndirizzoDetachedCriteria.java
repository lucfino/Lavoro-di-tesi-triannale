/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class EIndirizzoDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression ID;
	public final StringExpression regione;
	public final StringExpression provincia;
	public final StringExpression citta;
	public final StringExpression via;
	public final IntegerExpression civico;
	
	public EIndirizzoDetachedCriteria() {
		super(com.agenzia.immobiliare.client.entity.EIndirizzo.class, com.agenzia.immobiliare.client.entity.EIndirizzoCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		regione = new StringExpression("regione", this.getDetachedCriteria());
		provincia = new StringExpression("provincia", this.getDetachedCriteria());
		citta = new StringExpression("citta", this.getDetachedCriteria());
		via = new StringExpression("via", this.getDetachedCriteria());
		civico = new IntegerExpression("civico", this.getDetachedCriteria());
	}
	
	public EIndirizzoDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, com.agenzia.immobiliare.client.entity.EIndirizzoCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		regione = new StringExpression("regione", this.getDetachedCriteria());
		provincia = new StringExpression("provincia", this.getDetachedCriteria());
		citta = new StringExpression("citta", this.getDetachedCriteria());
		via = new StringExpression("via", this.getDetachedCriteria());
		civico = new IntegerExpression("civico", this.getDetachedCriteria());
	}
	
	public EIndirizzo uniqueEIndirizzo(PersistentSession session) {
		return (EIndirizzo) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public EIndirizzo[] listEIndirizzo(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (EIndirizzo[]) list.toArray(new EIndirizzo[list.size()]);
	}
}

