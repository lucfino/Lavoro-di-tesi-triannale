/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class Comuni implements Serializable {
	public Comuni() {
	}
	
	private int idcomune;
	
	private String nomecomune;
	
	private int idprovincia;
	
	private int idregione;
	
	private void setIdcomune(int value) {
		this.idcomune = value;
	}
	
	public int getIdcomune() {
		return idcomune;
	}
	
	public int getORMID() {
		return getIdcomune();
	}
	
	public void setNomecomune(String value) {
		this.nomecomune = value;
	}
	
	public String getNomecomune() {
		return nomecomune;
	}
	
	public void setIdprovincia(int value) {
		this.idprovincia = value;
	}
	
	public int getIdprovincia() {
		return idprovincia;
	}
	
	public void setIdregione(int value) {
		this.idregione = value;
	}
	
	public int getIdregione() {
		return idregione;
	}
	
	public String toString() {
		return String.valueOf(getIdcomune());
	}
	
}
