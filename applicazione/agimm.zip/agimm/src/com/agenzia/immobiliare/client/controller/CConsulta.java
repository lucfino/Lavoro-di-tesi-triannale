package com.agenzia.immobiliare.client.controller;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.Annuncio;
import com.agenzia.immobiliare.client.AnnuncioAsync;
import com.agenzia.immobiliare.client.Utility;
import com.agenzia.immobiliare.client.UtilityAsync;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.view.VConsulta;
import com.agenzia.immobiliare.client.view.VHome;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;

public class CConsulta {
	
	private AnnuncioAsync aa = GWT.create(Annuncio.class);
	
	private UtilityAsync ua = GWT.create(Utility.class);
	
	private static CConsulta consulta = null;
	
	private CConsulta(){}
	
	public static CConsulta getCConsulta(){
		if (consulta == null){
			consulta = new CConsulta();
		}
		return consulta;
	}
	
	public void cercaTerreni(final String reg, final int idreg, String pro, String cit, int prea, int preda, int supa, int supda, String prop, String col, final String cat, final String tipo){
		final CHome home = CHome.getCHome();
		final VConsulta consulta = VConsulta.getVConsulta();
			aa.cercaTerreni(reg, pro, cit, prea, preda, supa, supda, prop, col, new AsyncCallback<LinkedList<EAnnuncio>>(){

				@Override
				public void onFailure(Throwable caught) {
					Window.alert(caught.getMessage());
					
				}

				@Override
				public void onSuccess(LinkedList<EAnnuncio> result) {
					AbsolutePanel panel = consulta.getLista(result, cat, reg, idreg, tipo);
					home.impostaPagina(panel);
				}
	
				
			});
	}
	
	public void cercaGarage(final String reg, final int idreg, String pro, String cit, int prea, int preda, int supa, int supda, int gar, final String cat, final String tipo){
		final CHome home = CHome.getCHome();
		final VConsulta consulta = VConsulta.getVConsulta();
			aa.cercaGarage(reg, pro, cit, prea, preda, supa, supda, gar, new AsyncCallback<LinkedList<EAnnuncio>>(){
	
				@Override
				public void onFailure(Throwable caught) {
					Window.alert(caught.getMessage());
				}
	
				@Override
				public void onSuccess(LinkedList<EAnnuncio> result) {
					AbsolutePanel panel = consulta.getLista(result, cat, reg, idreg, tipo);
					home.impostaPagina(panel);
				}
				
			});
	}
	
	public void cercaResidenziali(final String reg, final int idreg, String pro, String cit, int prea, int preda, int supa, int supda,int camere, String stato, int locali, int piano, int totale_piani, boolean ascensore, String classe_energetica, String riscaldamento, String cucina, boolean garage, int bagni, String giardino, String balcone ,final String cat, final String tipo){
		//TODO
		}

	public void cercaAffitto(final String reg, final int idreg, String pro, String cit, int prea, int preda, int supa, int supda, int camere, String stato, int locali, int piano, int totale_piani, boolean ascensore, String classe_energetica, String riscaldamento, String cucina, boolean garage, int bagni, String giardino, String balcone ,final String cat, final String tipo, boolean arr, String contratto){
		//TODO
		}
	
	public void seleziona(int id, final String cat, final String tipo){
		final VConsulta consulta = VConsulta.getVConsulta();
		final CHome home = CHome.getCHome();
		aa.carica(id, new AsyncCallback<EAnnuncio>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(EAnnuncio result) {
				AbsolutePanel panel = consulta.getDettagli(result, cat, tipo);
				home.impostaPagina(panel);
			}
			
		});
	}

	public void accedi(String user, String pass) {
		ua.autentica(user, pass, new AsyncCallback<Boolean>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(Boolean result) {
				if (result){
					CHome home = CHome.getCHome();
					VHome vhome = VHome.getVHome();
					AbsolutePanel panel = vhome.getPanel();
					home.impostaPagina(panel);
				}else{
					Window.alert("controlla di aver inserito correttamente username e password");
				}
				
			}
			
		});		
	}

	public void logout() {
		ua.logout(new AsyncCallback<Void>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(Void result) {
				CHome home = CHome.getCHome();
				VHome vhome = VHome.getVHome();
				AbsolutePanel panel = vhome.getPanel();
				home.impostaPagina(panel);
			}
			
		});
		
	}

	public void salva(int id) {
		ua.salva(id, new AsyncCallback<Void>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(Void result) {
				
			}
			
		});
		
	}
	

}
