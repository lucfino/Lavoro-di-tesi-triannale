/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class ECommercialeCriteria extends AbstractORMCriteria {
	public final IntegerExpression ID;
	public final IntegerExpression superficie;
	public final IntegerExpression prezzo;
	
	public ECommercialeCriteria(Criteria criteria) {
		super(criteria);
		ID = new IntegerExpression("ID", this);
		superficie = new IntegerExpression("superficie", this);
		prezzo = new IntegerExpression("prezzo", this);
	}
	
	public ECommercialeCriteria(PersistentSession session) {
		this(session.createCriteria(ECommerciale.class));
	}
	
	public ECommercialeCriteria() throws PersistentException {
		this(com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession());
	}
	
	public EIndirizzoCriteria createEIndirizzoCriteria() {
		return new EIndirizzoCriteria(createCriteria("eIndirizzo"));
	}
	
	public ECommerciale uniqueECommerciale() {
		return (ECommerciale) super.uniqueResult();
	}
	
	public ECommerciale[] listECommerciale() {
		java.util.List list = super.list();
		return (ECommerciale[]) list.toArray(new ECommerciale[list.size()]);
	}
}

