/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class Provincie implements Serializable {
	public Provincie() {
	}
	
	private int idprovincia;
	
	private String nomeprovincia;
	
	private String siglaprovincia;
	
	private int idregione;
	
	private void setIdprovincia(int value) {
		this.idprovincia = value;
	}
	
	public int getIdprovincia() {
		return idprovincia;
	}
	
	public int getORMID() {
		return getIdprovincia();
	}
	
	public void setNomeprovincia(String value) {
		this.nomeprovincia = value;
	}
	
	public String getNomeprovincia() {
		return nomeprovincia;
	}
	
	public void setSiglaprovincia(String value) {
		this.siglaprovincia = value;
	}
	
	public String getSiglaprovincia() {
		return siglaprovincia;
	}
	
	public void setIdregione(int value) {
		this.idregione = value;
	}
	
	public int getIdregione() {
		return idregione;
	}
	
	public String toString() {
		return String.valueOf(getIdprovincia());
	}
	
}
