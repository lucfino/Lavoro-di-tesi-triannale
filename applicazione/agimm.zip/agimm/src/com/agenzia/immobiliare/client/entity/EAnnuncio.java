/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class EAnnuncio implements Serializable {
	public EAnnuncio() {
	}
	
	public EAnnuncio(EImmobile imm, String desc, String tit){
		this.eImmobile=imm;
		this.titolo=tit;
		this.descrizione=desc;
	}
	
	private int ID;
	
	private com.agenzia.immobiliare.client.entity.EImmobile eImmobile;
	
	private String descrizione;
	
	private String titolo;
	
	private String[] foto;
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setDescrizione(String value) {
		this.descrizione = value;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public void setFoto(String[] value) {
		this.foto = value;
	}
	
	public String[] getFoto() {
		return foto;
	}
	
	public void setTitolo(String value) {
		this.titolo = value;
	}
	
	public String getTitolo() {
		return titolo;
	}
	
	public void seteImmobile(com.agenzia.immobiliare.client.entity.EImmobile value) {
		this.eImmobile = value;
	}
	
	public com.agenzia.immobiliare.client.entity.EImmobile geteImmobile() {
		return eImmobile;
	}
	
	public String toString() {
		return String.valueOf(getID());
	}

	public EResidenziale geteResidenziale() {
		// TODO Auto-generated method stub
		return (EResidenziale) eImmobile;
	}

	public EAffitto geteAffitto() {
		// TODO Auto-generated method stub
		return (EAffitto) eImmobile;
	}

	public Garage geteGarage() {
		// TODO Auto-generated method stub
		return (Garage) eImmobile;
	}

	public Terreni geteTerreni() {
		// TODO Auto-generated method stub
		return (Terreni) eImmobile;
	}
	
}
