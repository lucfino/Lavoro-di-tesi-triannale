package com.agenzia.immobiliare.client;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.view.IVMapsAdapter;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface UtilityAsync{
	
	void esiste(String path, AsyncCallback<String[]> callback);
	
	void autentica(String user, String pass, AsyncCallback<Boolean> callback);

	void controlla(AsyncCallback<String> callback);
	
	void loggato(AsyncCallback<Boolean> callback);
	
	void logout(AsyncCallback<Void> callback);
	
	void salva(int id, AsyncCallback<Void> callback);
	
	void carica(AsyncCallback<LinkedList<EAnnuncio>> callback);
	
	void carica(String name, AsyncCallback<IVMapsAdapter> callback);
	
}
