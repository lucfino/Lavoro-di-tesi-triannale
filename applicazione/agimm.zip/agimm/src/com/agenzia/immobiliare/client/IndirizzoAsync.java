package com.agenzia.immobiliare.client;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.Provincie;
import com.agenzia.immobiliare.client.entity.Regioni;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The client side stub for the RPC service.
 */
public interface IndirizzoAsync {
	
	void cercaRegioni(AsyncCallback<Regioni[]> callback);
	
	void cercaProvincie(int id, AsyncCallback<LinkedList<Provincie>> callback);
	
	void cercaComuni(int id, AsyncCallback<LinkedList<String>> callback);	
	
}
