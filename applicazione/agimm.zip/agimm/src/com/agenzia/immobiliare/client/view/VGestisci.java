package com.agenzia.immobiliare.client.view;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.Annuncio;
import com.agenzia.immobiliare.client.AnnuncioAsync;
import com.agenzia.immobiliare.client.Indirizzo;
import com.agenzia.immobiliare.client.IndirizzoAsync;
import com.agenzia.immobiliare.client.controller.CGestisci;
import com.agenzia.immobiliare.client.entity.Agenzia;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.entity.Garage;
import com.agenzia.immobiliare.client.entity.EIndirizzo;
import com.agenzia.immobiliare.client.entity.Provincie;
import com.agenzia.immobiliare.client.entity.Regioni;
import com.agenzia.immobiliare.client.entity.Terreni;
import com.agenzia.immobiliare.shared.Config;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.BlurEvent;
import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.IntegerBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.TextArea;

public class VGestisci{
	
	private VGestisci(){}
	
	private static VGestisci gestisci;
	
	private AnnuncioAsync aa = GWT.create(Annuncio.class);

	private IndirizzoAsync gsa = GWT.create(Indirizzo.class);

	
	public static VGestisci getVGestisci(){
		if (gestisci == null){
			gestisci = new VGestisci();
		}
		return gestisci;
	}
	
	public AbsolutePanel gethomeAdmin(){
		Config config = Config.getConfig();
		VHome home = VHome.getVHome();
		AbsolutePanel datiAgenzia = new AbsolutePanel();
		datiAgenzia.setSize("1440", "800");
		datiAgenzia.setStyleName(config.getStile());
		
		
		AbsolutePanel login = home.getLogin();
		datiAgenzia.add(login, 191, 20);
		login.setSize("1032px", "188px");
		

		AbsolutePanel absolutePanel = getLaterale();
		datiAgenzia.add(absolutePanel, 193, 223);
		absolutePanel.setStyleName(config.getStile()+"-panel");
		absolutePanel.setSize("190px", "496px");
		
		
		return datiAgenzia;
	}

	public AbsolutePanel getInserisci(){
		Config config = Config.getConfig();
		VHome home = VHome.getVHome();
		final AbsolutePanel panel = new AbsolutePanel();
		panel.setStyleName(config.getStile());
		panel.setSize("1424px", "800px");
		
		
		
		AbsolutePanel login = home.getLogin();
		panel.add(login, 191, 20);
		login.setSize("1032px", "188px");
		
		AbsolutePanel absolutePanel_1 = new AbsolutePanel();
		panel.add(absolutePanel_1, 401, 223);
		absolutePanel_1.setSize("563px", "496px");
		
		AbsolutePanel absolutePanel_6 = getLaterale();
		panel.add(absolutePanel_6, 193, 223);
		absolutePanel_6.setStyleName(config.getStile()+"-panel");
		absolutePanel_6.setSize("190px", "496px");
		
		final ListBox tipologia = new ListBox();
		absolutePanel_1.add(tipologia, 10, 30);
		tipologia.setSize("140px", "22px");
		tipologia.addItem("residenziale","residenziale");
		tipologia.addItem("commerciale","commerciale");
		
		final TextBox titolo = new TextBox();
		absolutePanel_1.add(titolo, 10, 180);
		titolo.setSize("206px", "18px");
		
		final IntegerBox superficie = new IntegerBox();
		absolutePanel_1.add(superficie, 290, 34);
		
		final IntegerBox prezzo = new IntegerBox();
		absolutePanel_1.add(prezzo, 290, 132);
		
		Label lblTipologia = new Label("tipologia :");
		absolutePanel_1.add(lblTipologia, 10, 10);
		
		Label lblTitolo = new Label("titolo dell'annuncio :");
		absolutePanel_1.add(lblTitolo, 10, 156);
		
		Label lblSuperficiemq = new Label("superficie (mq) :");
		absolutePanel_1.add(lblSuperficiemq, 290, 10);
		
		Label lblPrezzoeuro = new Label("prezzo (euro) :");
		absolutePanel_1.add(lblPrezzoeuro, 290, 108);
		
		final TextArea descrizione = new TextArea();
		absolutePanel_1.add(descrizione, 10, 294);
		descrizione.setSize("206px", "142px");
		
		Label lblDescrizione = new Label("descrizione dell'immobile :");
		absolutePanel_1.add(lblDescrizione, 10, 270);
		
		final ListBox regione = getRegioni();
		absolutePanel_1.add(regione, 290, 241);
		regione.setSize("136px", "22px");
		regione.addItem("-regione-","0");
		final ListBox provincia = new ListBox();
		absolutePanel_1.add(provincia, 290, 294);
		provincia.addItem("-provincia-","0");
		provincia.setEnabled(false);
		provincia.setSize("140px", "22px");
		final ListBox citta = new ListBox();
		absolutePanel_1.add(citta, 290, 348);
		citta.addItem("-citta-","0");
		citta.setEnabled(false);
		citta.setSize("140px", "22px");
		
		Label label = new Label("");
		absolutePanel_1.add(label, 10, 228);
		label.setSize("216px", "36px");
		
		Label label_1 = new Label("");
		absolutePanel_1.add(label_1, 10, 452);
		label_1.setSize("216px", "36px");
		
		final TextBox via = new TextBox();
		absolutePanel_1.add(via, 290, 412);
		via.setSize("206px", "18px");
		
		Label lblVia = new Label("via");
		absolutePanel_1.add(lblVia, 290, 388);
		
		Label label_2 = new Label("");
		absolutePanel_1.add(label_2, 290, 452);
		label_2.setSize("216px", "36px");
		
		Label label_3 = new Label("");
		absolutePanel_1.add(label_3, 290, 66);
		label_3.setSize("216px", "36px");
		
		Label label_4 = new Label("");
		absolutePanel_1.add(label_4, 290, 164);
		label_4.setSize("216px", "36px");
		
		final ListBox tipo = new ListBox();
		absolutePanel_1.add(tipo, 10, 92);
		tipo.setSize("136px", "22px");
		tipo.addItem("-tipologia-", "0");
		tipo.addItem("in vendita", "in vendita");
		tipo.addItem("in affitto", "in affitto");
		
		final AbsolutePanel absolutePanel_2 = new AbsolutePanel();
		panel.add(absolutePanel_2, 970, 223);
		absolutePanel_2.setSize("248px", "496px");
		absolutePanel_2.setVisible(false);
		Label lposti = new Label("posti auto");
		final ListBox posti = new ListBox();
		posti.addItem("-posti auto-","0");
		posti.addItem("1","1");
		posti.addItem("2","2");
		posti.addItem("3","3");
		Button btnInserisci = new Button("INSERISCI");
		absolutePanel_2.add(lposti);
		absolutePanel_2.add(posti);
		absolutePanel_2.add(btnInserisci);
		
		
		final AbsolutePanel absolutePanel_3 = new AbsolutePanel();
		panel.add(absolutePanel_3, 970, 223);
		absolutePanel_3.setSize("248px", "496px");
		absolutePanel_3.setVisible(false);
		Label lcolture = new Label("colture");
		final ListBox colture = new ListBox();
		colture.addItem("-colture-","0");
		colture.addItem("rape","rape");
		Label lproprieta = new Label("proprieta");
		final ListBox proprieta = new ListBox();
		proprieta.addItem("-proprieta-","0");
		proprieta.addItem("p1","p2");
		Button btnInserisc2 = new Button("INSERISCI");
		absolutePanel_3.add(lcolture);
		absolutePanel_3.add(lproprieta);
		absolutePanel_3.add(colture);
		absolutePanel_3.add(proprieta);
		absolutePanel_3.add(btnInserisc2);
		
		btnInserisci.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				String tit = titolo.getText();
				String desc = descrizione.getText();
				int pre = prezzo.getValue();
				int sup = superficie.getValue();
				String reg = regione.getItemText(regione.getSelectedIndex());
				String pro = provincia.getItemText(provincia.getSelectedIndex());
				String cit = citta.getItemText(citta.getSelectedIndex());
				String vi = via.getText();
				int pos = Integer.parseInt(posti.getValue(posti.getSelectedIndex()));
				EIndirizzo ind = new EIndirizzo(reg, pro, cit, vi, 12);
				Garage gar = new Garage(ind, sup, pre, pos);
				EAnnuncio ann = new EAnnuncio(gar, tit, desc);
				CGestisci gestisci = CGestisci.getCGestisci();
				gestisci.inserisciGarage(ann);
			}
			
		});
		btnInserisc2.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				String tit = titolo.getText();
				String desc = descrizione.getText();
				int pre = prezzo.getValue();
				int sup = superficie.getValue();
				String reg = regione.getItemText(regione.getSelectedIndex());
				String pro = provincia.getItemText(provincia.getSelectedIndex());
				String cit = citta.getItemText(citta.getSelectedIndex());
				String vi = via.getText();
				String col = colture.getItemText(colture.getSelectedIndex());
				String prop = proprieta.getItemText(proprieta.getSelectedIndex());
				EIndirizzo ind = new EIndirizzo(reg, pro, cit, vi, 12);
				Terreni ter = new Terreni(ind, sup, pre, col, prop);
				EAnnuncio ann = new EAnnuncio(ter, tit, desc);
				CGestisci gestisci = CGestisci.getCGestisci();
				gestisci.inserisciTerreni(ann);
				
			}
			
		});
		
		provincia.addChangeHandler(new ChangeHandler(){
			@Override
			public void onChange(ChangeEvent event) {
				int pro = Integer.parseInt(provincia.getValue(provincia.getSelectedIndex()));
				if (pro != 0){
					getComuni(pro, citta);
				}else{
					citta.setEnabled(false);
					citta.setSelectedIndex(0);
				}
			}
		});
		regione.addChangeHandler(new ChangeHandler(){
			@Override
			public void onChange(ChangeEvent event) {
				int reg = Integer.parseInt(regione.getValue(regione.getSelectedIndex()));
				if(reg != 0){
					getProvincie(reg, provincia);
				}else{
					provincia.setEnabled(false);
					provincia.setSelectedIndex(0);
					citta.setEnabled(false);
					citta.setSelectedIndex(0);
				}
			}
		});
		tipologia.addChangeHandler(new ChangeHandler(){

			@Override
			public void onChange(ChangeEvent event) {
				if (tipologia.getValue(tipologia.getSelectedIndex()).equals("commerciale")){
					tipo.clear();
					tipo.addItem("-tipologia-", "0");
					tipo.addItem("garage", "garage");
					tipo.addItem("terreni", "terreni");
				}else{
					tipo.addItem("-tipologia-", "0");
					tipo.addItem("in vendita", "in vendita");
					tipo.addItem("in affitto", "in affitto");
				}
				
			}
			
		});
		
		tipo.addChangeHandler(new ChangeHandler(){

			@Override
			public void onChange(ChangeEvent event) {
				if (tipologia.getItemText(tipologia.getSelectedIndex()).equals("commerciale")){
					if (tipo.getItemText(tipo.getSelectedIndex()).equals("garage")){
						absolutePanel_2.setVisible(true);
						absolutePanel_3.setVisible(false);
					}else{
						absolutePanel_2.setVisible(false);
						absolutePanel_3.setVisible(true);
					}
				}else {
					if (tipo.getItemText(tipo.getSelectedIndex()).equals("in vendita")){
						//TODO
					}else{
						//TODO
					}
				}
				
			}
			
		});
		
		
		return panel;
	}

	public AbsolutePanel getCerca() {
		AbsolutePanel panel = new AbsolutePanel();
		VHome home = VHome.getVHome();
		panel.setSize("1440px", "900px");
		Config config = Config.getConfig();
		panel.setStyleName(config.getStile());
		
		
		AbsolutePanel login = home.getLogin();
		panel.add(login, 191, 20);
		login.setSize("1032px", "188px");
		
		
		Label id = new Label("scegli l'id di un annuncio");
		panel.add(id, 400, 223);
		id.setSize("149px", "16px");
		final ListBox tid = getID();
		panel.add(tid, 555, 223);
		tid.setSize("82px", "22px");
		
		AbsolutePanel absolutePanel = getLaterale();
		panel.add(absolutePanel, 193, 223);
		absolutePanel.setStyleName(config.getStile()+"-panel");
		absolutePanel.setSize("190px", "496px");
		
		
		return panel;
	}
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public AbsolutePanel getModificaAgenzia(Agenzia ag) {
		Config config = Config.getConfig();
		VHome home = VHome.getVHome();
		final AbsolutePanel panel = new AbsolutePanel();
		panel.setStyleName(config.getStile());
		panel.setSize("1424px", "800px");
		
		AbsolutePanel absolutePanel = getLaterale();
		panel.add(absolutePanel, 193, 223);
		absolutePanel.setStyleName(config.getStile()+"-panel");
		absolutePanel.setSize("190px", "496px");
		
		AbsolutePanel login = home.getLogin();
		panel.add(login, 191, 20);
		login.setSize("1032px", "188px");
		
		AbsolutePanel absolutePanel_1 = new AbsolutePanel();
		panel.add(absolutePanel_1, 400, 223);
		absolutePanel_1.setSize("818px", "376px");
		
		final TextBox nome = new TextBox();
		absolutePanel_1.add(nome, 10, 46);
		nome.setText(ag.getNome());
		
		Label lnome = new Label("nome :");
		absolutePanel_1.add(lnome, 10, 22);
		
		final TextBox indirizzo = new TextBox();
		absolutePanel_1.add(indirizzo, 10, 142);
		indirizzo.setSize("173", "34");
		indirizzo.setText(ag.getIndirizzo());
		
		Label lindirizzo = new Label("indirizzo :");
		absolutePanel_1.add(lindirizzo, 10, 118);
		lindirizzo.setSize("56px", "18px");
		
		final TextBox fax = new TextBox();
		absolutePanel_1.add(fax, 10, 237);
		fax.setSize("173", "34");
		fax.setText(ag.getFax());
		
		Label lfax = new Label("fax :");
		absolutePanel_1.add(lfax, 10, 213);
		lfax.setSize("56px", "18px");
		
		final TextBox telefono = new TextBox();
		absolutePanel_1.add(telefono, 10, 332);
		telefono.setSize("173", "34");
		telefono.setText(String.valueOf(ag.getTelefono()));
		
		Label ltelefono = new Label("telefono :");
		absolutePanel_1.add(ltelefono, 10, 308);
		ltelefono.setSize("56px", "18px");
		
		final TextBox email = new TextBox();
		absolutePanel_1.add(email, 281, 46);
		email.setSize("173", "34");
		email.setText(ag.getEmail());
		
		Label lemail = new Label("email :");
		absolutePanel_1.add(lemail, 281, 22);
		lemail.setSize("56px", "18px");
		
		final TextBox username = new TextBox();
		absolutePanel_1.add(username, 281, 142);
		username.setSize("173", "34");
		username.setText(ag.getUsername());
		
		Label lusername = new Label("username :");
		absolutePanel_1.add(lusername, 281, 118);
		lusername.setSize("173px", "18px");
		
		final PasswordTextBox password = new PasswordTextBox();
		absolutePanel_1.add(password, 281, 237);
		password.setSize("173", "34");
		password.setText(ag.getPassword());
		
		Label lpassword = new Label("password :");
		absolutePanel_1.add(lpassword, 281, 213);
		lpassword.setSize("157px", "18px");
		
		PasswordTextBox conferma = new PasswordTextBox();
		absolutePanel_1.add(conferma, 281, 332);
		conferma.setSize("173", "34");
		conferma.setText(ag.getPassword());
		
		Label lconferma = new Label("conferma password:");
		absolutePanel_1.add(lconferma, 281, 308);
		lconferma.setSize("157px", "18px");
		
		Label ldesrizione = new Label("descrizione :");
		absolutePanel_1.add(ldesrizione, 553, 22);
		
		final TextArea descrizione = new TextArea();
		absolutePanel_1.add(descrizione, 553, 46);
		descrizione.setSize("223px", "175px");
		descrizione.setText(ag.getDescrizione());
		
		Button btnModifica = new Button("MODIFICA");
		absolutePanel_1.add(btnModifica, 609, 336);
		btnModifica.addClickHandler(new ClickHandler(){
	
			@Override
			public void onClick(ClickEvent event) {
				String nom = nome.getText();
				String ind = indirizzo.getText();
				String fa = fax.getText();
				int tel = Integer.parseInt(telefono.getText());
				String mail = email.getText();
				String user = username.getText();
				String pass = password.getText();
				String desc = descrizione.getText();
				CGestisci gestisci = CGestisci.getCGestisci();
				gestisci.modificaAgenzia(ind, nom, fa, user, pass, mail, desc, tel);
			}
			
		});
		
		nome.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		indirizzo.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		fax.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		
		telefono.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		email.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		username.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		conferma.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		descrizione.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		return panel;
	}

	public AbsolutePanel getAnnuncio(final EAnnuncio ann, String scegli){
		AbsolutePanel panel = new AbsolutePanel();
		panel.setStyleName("bordo");
		//title
		Label titolo = new Label(ann.getTitolo());
		panel.add(titolo, 10, 10);
		titolo.setSize("564px", "30px");
		//description 
		Label desc = new Label(ann.getDescrizione());
		panel.add(desc, 10, 379);
		desc.setSize("564px", "113px");
		AbsolutePanel galleria = new AbsolutePanel();
		galleria.setStyleName("ricerca");
		panel.add(galleria, 10, 95);
		galleria.setSize("564px", "272px");
		//important 
		AbsolutePanel dati_principali = new AbsolutePanel();
		dati_principali.setStyleName("ricerca");
		panel.add(dati_principali, 10, 46);
		dati_principali.setSize("292px", "29px");
		Label superficie = new Label();
		Label prezzo = new Label();
		Label indirizzo = new Label();
		superficie.setText(String.valueOf(ann.geteImmobile().getSuperficie()));
		prezzo.setText(String.valueOf(ann.geteImmobile().getPrezzo()));	
		indirizzo.setText(ann.geteImmobile().geteIndirizzo().toString());
		dati_principali.add(superficie, 0, 0);
		superficie.setSize("60px", "16px");
		dati_principali.add(prezzo, 66, 0);
		prezzo.setSize("60px", "16px");
		dati_principali.add(indirizzo, 132, 0);
		indirizzo.setSize("60px", "16px");
		Button b = new Button();
		final CGestisci gestisci = CGestisci.getCGestisci();
		if (scegli.equals("elimina")){
			b.setText("elimina");
			b.addClickHandler(new ClickHandler(){

				@Override
				public void onClick(ClickEvent event) {
					gestisci.cancella(ann);
				}
				
			});
		}else{
			b.setText("modifica");
			b.addClickHandler(new ClickHandler(){

				@Override
				public void onClick(ClickEvent event) {
					VGestisci vgestisci = new VGestisci();
					vgestisci.getInserisci();
				}
				
		});
	}
	panel.add(b);
	return panel;
	}
	
	
	private void getComuni(int id, final ListBox l){
		l.clear();
		l.setEnabled(true);
		l.addItem("-citta-","0");
		gsa .cercaComuni(id, new AsyncCallback<LinkedList<String>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<String> result) {
				for (int i=0; i<result.size(); i++){
					l.addItem(result.get(i).toLowerCase(),result.get(i).toLowerCase()); 
				}
			}
		});
	}
	
	private void getProvincie(int id, final ListBox l) {
		l.clear();
		l.setEnabled(true);
		l.addItem("-provincia-", "0");
		gsa.cercaProvincie(id,new AsyncCallback<LinkedList<Provincie>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<Provincie> result) {
				for (int i=0; i<result.size(); i++){
					l.addItem(result.get(i).getNomeprovincia().toLowerCase(),String.valueOf(result.get(i).getIdprovincia()));
				}
				
			}
			
		});
	}
	
	private ListBox getID(){
		final ListBox l_1 = new ListBox();
		l_1.addItem("-id-", "0");
		aa.cerca(new AsyncCallback<LinkedList<EAnnuncio>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<EAnnuncio> result) {
				for (int i=0; i<result.size(); i++){
					l_1.addItem(String.valueOf(result.get(i).getID()),String.valueOf(result.get(i).getID()));
				}
			}
		});	
		return l_1;	
	}
	
	private ListBox getRegioni() {
		final ListBox l_2 = new ListBox();
		l_2.addItem("-regione-","0");
		gsa.cercaRegioni(new AsyncCallback<Regioni[]>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(Regioni[] result) {
				for (int i=1; i<result.length; i++){
					l_2.addItem(result[i].getNomeregione().toLowerCase(),String.valueOf(result[i].getIdregioni()));
				}
				
			}
			
		});
		return l_2;
	}

	private AbsolutePanel getLaterale(){
		AbsolutePanel absolutePanel_6 = new AbsolutePanel();
		absolutePanel_6 = new AbsolutePanel();
		Button inserisci = new Button("INSERISCI ANNUNCIO");
		absolutePanel_6.add(inserisci, 10, 10);
		inserisci.setSize("173px", "38px");
		inserisci.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				CGestisci gestisci = CGestisci.getCGestisci();
				gestisci.formInserisci();
				
			}
			
		});
		Button elimina = new Button("ELIMINA ANNUNCIO");
		absolutePanel_6.add(elimina, 10, 311);
		elimina.setSize("173px", "38px");
		elimina.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				CGestisci gestisci = CGestisci.getCGestisci();
				gestisci.formCerca("elimina");
				
			}
			
		});
		Button modifica = new Button("MODIFICA ANNUNCIO");
		absolutePanel_6.add(modifica, 10, 165);
		modifica.setSize("173px", "38px");
		Button modificaAgenzia = new Button("MODIFICA DATI AGENZIA");
		absolutePanel_6.add(modificaAgenzia, 10, 448);
		modificaAgenzia.setSize("173px", "38px");
		modificaAgenzia.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				CGestisci gestisci = CGestisci.getCGestisci();
				gestisci.formModificaAgenzia();
				
			}
			
		});
		
		return absolutePanel_6;
	}
}
