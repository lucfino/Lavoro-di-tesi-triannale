/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class EAffitto extends com.agenzia.immobiliare.client.entity.EResidenziale implements Serializable {
	public EAffitto() {
	}
	
	public EAffitto(EIndirizzo ind, int sup, int pre, String con, boolean arr){
		super(ind, sup, pre);
		this.arredato=arr;
		this.contratto=con;
		
	}
	
	private String contratto;
	
	private boolean arredato;
	
	public String toString() {
		return super.toString();
	}

	public void setContratto(String contratto) {
		this.contratto = contratto;
	}

	public String getContratto() {
		return contratto;
	}

	public void setArredato(boolean arredato) {
		this.arredato = arredato;
	}

	public boolean isArredato() {
		return arredato;
	}
	
}
