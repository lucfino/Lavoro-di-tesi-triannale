package com.agenzia.immobiliare.client.controller;

import com.agenzia.immobiliare.client.Utility;
import com.agenzia.immobiliare.client.UtilityAsync;
import com.agenzia.immobiliare.client.view.VHome;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;

public class CHome {
	
	private UtilityAsync ua = GWT.create(Utility.class);
	
	private CHome(){
	}
	
	private static CHome home;
	
	public static CHome getCHome(){
		if (home == null){
			home = new CHome();
		}
		return home;
	}
	
	public void impostaPagina(final AbsolutePanel panel) {
		ua.controlla(new AsyncCallback<String>(){	

		@Override
		public void onFailure(Throwable caught) {
			Window.alert(caught.getMessage());
							
		}

		@Override
		public void onSuccess(String result) {
			if (result.equals("")){
				mostra(panel);
			}else{
				Window.alert(result);
			}
		}
						
		});
	}
	
	public void mostra(AbsolutePanel panel){
		VHome home = VHome.getVHome();
		home.stampa(panel);
	}
	
	
	
}
