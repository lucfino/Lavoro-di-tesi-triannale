package com.agenzia.immobiliare.client;

import com.agenzia.immobiliare.client.controller.CHome;
import com.agenzia.immobiliare.client.view.VHome;
import com.agenzia.immobiliare.client.view.VInstalla;
import com.agenzia.immobiliare.shared.Config;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;
/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Agimm implements EntryPoint {

	private UtilityAsync ua = GWT.create(Utility.class);

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		ua.esiste("config.properties", new AsyncCallback<String[]>(){

			@Override
			public void onFailure(Throwable caught) {
				//TODO Auto-generated method stub
			}

			@Override
			public void onSuccess(String[] result) {
				AbsolutePanel panel = new AbsolutePanel();
				CHome chome = CHome.getCHome();
				if (result[0].equals("esiste")){
					Config config = Config.getConfig();
					config.setNome(result[1]);
					config.setIndirizzo(result[2]);
					config.setEmail(result[3]);
					config.setFax(1234/*Integer.parseInt(result[3])*/);
					config.setLogo(result[5]);
					config.setDesc(result[6]);
					config.setTelefono(Integer.parseInt(result[7]));
					config.setNomeDB(result[8]);
					config.setPosizioneDB(result[9]);
					config.setPasswprdDB(result[10]);
					config.setServerMail(result[11]);
					config.setPortaMail(Integer.parseInt(result[12]));
					config.setUsernameMail(result[13]);
					config.setPasswordMail(result[14]);
					config.setUsernameDB(result[15]);
					config.setPasswprdDB(result[16]);
					config.setStile(result[17]);
					config.setMaps(result[18]);
					VHome vhome = VHome.getVHome();
					panel = vhome.getPanel();
				}else{
					VInstalla installa = VInstalla.getVInstalla();
					panel = installa.getHello();
				}
				chome.impostaPagina(panel);
			}
		});
		
	}
}
