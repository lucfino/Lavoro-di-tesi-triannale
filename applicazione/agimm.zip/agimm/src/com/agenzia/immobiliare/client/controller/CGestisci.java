package com.agenzia.immobiliare.client.controller;

import com.agenzia.immobiliare.client.AgenziaService;
import com.agenzia.immobiliare.client.AgenziaServiceAsync;
import com.agenzia.immobiliare.client.Annuncio;
import com.agenzia.immobiliare.client.AnnuncioAsync;
import com.agenzia.immobiliare.client.entity.Agenzia;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.view.VGestisci;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;

public class CGestisci {
	
	private AnnuncioAsync aa = GWT.create(Annuncio.class);
	
	public AgenziaServiceAsync as = GWT.create(AgenziaService.class);
	
	private CGestisci(){}
	
	private static CGestisci gestisci = null;
	
	public static CGestisci getCGestisci(){
		if (gestisci == null){
			gestisci = new CGestisci();
		}
		return gestisci;
	}
	
	public void homeAdmin(){
		VGestisci gestisci = VGestisci.getVGestisci();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = gestisci.gethomeAdmin();
		home.impostaPagina(panel);
	}
	
	public void formInserisci(){
		VGestisci gestisci = VGestisci.getVGestisci();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = gestisci.getInserisci();
		home.impostaPagina(panel);
	}
	
	public void inserisciGarage(EAnnuncio ann){
		aa.inserisciGarage(ann, new AsyncCallback<Boolean>(){
			
			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(Boolean result) {
				CGestisci gestisci = new CGestisci();
				gestisci.homeAdmin();
			}
			
		});
		
	}
	
	public void cancella(EAnnuncio ann){
		aa.cancella(ann.getID(), new AsyncCallback<Boolean>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(Boolean result) {
				CGestisci gestisci = new CGestisci();
				gestisci.homeAdmin();
				
			}
			
		});
	}
		
	public void cerca(int id, final String scegli){
		aa.carica(id, new AsyncCallback<EAnnuncio>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(final EAnnuncio ann) {
				VGestisci gestisci = VGestisci.getVGestisci();
				CHome home = CHome.getCHome();
				AbsolutePanel panel = gestisci.getAnnuncio(ann, scegli);
				home.impostaPagina(panel);
			}
		});
	}

	public void formCerca(String scegli) {
		VGestisci gestisci = VGestisci.getVGestisci();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = gestisci.getCerca();
		home.impostaPagina(panel);
		
	}

	public void formModificaAgenzia() {
		as.carica(new AsyncCallback<Agenzia>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(Agenzia result) {
				VGestisci gestisci = VGestisci.getVGestisci();
				CHome home = CHome.getCHome();
				AbsolutePanel panel = gestisci.getModificaAgenzia(result);
				home.impostaPagina(panel);
			}
			
		});
		
	}

	public void inserisciTerreni(EAnnuncio ann) {
		aa.inserisciTerreni(ann, new AsyncCallback<Boolean>(){
			
			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(Boolean result) {
				CGestisci gestisci = new CGestisci();
				gestisci.homeAdmin();
			}
			
		});
		
	}

	public void modificaAgenzia(Agenzia ag) {
		
		
	}

	public void modificaAgenzia(String ind, String nom, String fa, String user,
			String pass, String mail, String desc, int tel) {
		as.modifica(ind, nom, fa, user, pass, mail, desc, tel, new AsyncCallback<Boolean>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(Boolean result) {
				CGestisci gestisci = new CGestisci();
				gestisci.homeAdmin();
			}
			
		});
		
	}

	
}
