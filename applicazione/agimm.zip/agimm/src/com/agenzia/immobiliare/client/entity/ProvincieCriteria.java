/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class ProvincieCriteria extends AbstractORMCriteria {
	public final IntegerExpression idprovincia;
	public final StringExpression nomeprovincia;
	public final StringExpression siglaprovincia;
	public final IntegerExpression idregione;
	
	public ProvincieCriteria(Criteria criteria) {
		super(criteria);
		idprovincia = new IntegerExpression("idprovincia", this);
		nomeprovincia = new StringExpression("nomeprovincia", this);
		siglaprovincia = new StringExpression("siglaprovincia", this);
		idregione = new IntegerExpression("idregione", this);
	}
	
	public ProvincieCriteria(PersistentSession session) {
		this(session.createCriteria(Provincie.class));
	}
	
	public ProvincieCriteria() throws PersistentException {
		this(com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession());
	}
	
	public Provincie uniqueProvincie() {
		return (Provincie) super.uniqueResult();
	}
	
	public Provincie[] listProvincie() {
		java.util.List list = super.list();
		return (Provincie[]) list.toArray(new Provincie[list.size()]);
	}
}

