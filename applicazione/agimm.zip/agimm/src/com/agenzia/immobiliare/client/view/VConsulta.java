package com.agenzia.immobiliare.client.view;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.Indirizzo;
import com.agenzia.immobiliare.client.IndirizzoAsync;
import com.agenzia.immobiliare.client.controller.CConsulta;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.entity.Provincie;
import com.agenzia.immobiliare.shared.Config;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.IntegerBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.TabPanel;

public class VConsulta{
	
	private VConsulta(){}
	
	private static VConsulta consulta;
	
	private int count = 1;

	private IndirizzoAsync gsa = GWT.create(Indirizzo.class);
	
	public static VConsulta getVConsulta(){
		if (consulta == null){
			consulta = new VConsulta();
		}
		return consulta;
	}

	
	public AbsolutePanel getLista(LinkedList<EAnnuncio> lista,final String cat, final String reg, int idreg, final String tipo){
		final Config config = Config.getConfig();
		VHome home = VHome.getVHome();
		AbsolutePanel panel = new AbsolutePanel();
		panel.setSize("1440px", "796px");
		panel.setStyleName(config.getStile());
		final AbsolutePanel ricerca = getRicerca(cat, tipo, reg, idreg);
		panel.add(ricerca, 193, 228);
		ricerca.setStyleName(config.getStile()+"-panel");
		
		AbsolutePanel login = home.getLogin();
		panel.add(login, 191, 20);
		
		TabPanel tabPanel = new TabPanel();
		tabPanel.setAnimationEnabled(true);
		panel.add(tabPanel, 521, 228);
		tabPanel.setSize("707px", "517px");
		final FlexTable table_1 = getTable(lista, cat, tipo);
		table_1.setStyleName(config+"-label");
		tabPanel.add(table_1, "Lista", false);
		table_1.setSize("693px", "112px");
		LinkedList<EAnnuncio> l = new LinkedList<EAnnuncio>();
		for (int i=0; i<lista.size(); i++){
			l.add(lista.get(i));
		}
		//MapsFactory map = MapsFactory.getMapsFactory();
		//MapWidget listmap = map.getMapsAdapter().getMapbyList(6, l, cat, tipo);
		VMapsAdapter map = new VMapsAdapter();
		MapWidget listmap = map.getMapbyList(9, l, cat, tipo);
		listmap.setSize("693px","500px");
		tabPanel.add(listmap, "Mappa", false);

		tabPanel.selectTab(1);
		table_1.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				int index = table_1.getCellForEvent(event).getRowIndex();
				int id = Integer.parseInt(table_1.getWidget(index, 0).getTitle());
				CConsulta consulta =  CConsulta.getCConsulta();
				consulta.seleziona(id, cat, tipo);
				}
		});
		login.setSize("1032px", "188px");
		return panel;
	}

	public AbsolutePanel getDettagli(final EAnnuncio ann,String cat, String tipo){
		Config config = Config.getConfig();
		VHome home = VHome.getVHome();
		
		AbsolutePanel panel = new AbsolutePanel();
		panel.setSize("1440px", "1012px");
		panel.setStyleName(config.getStile());
	
		AbsolutePanel login = home.getLogin();
		panel.add(login, 191, 20);
		login.setSize("1032px", "188px");
		
		Label titolo = new Label(ann.getTitolo());
		panel.add(titolo, 193, 214);
		titolo.setSize("276px", "29px");
		
		Label desc = new Label(ann.getDescrizione());
		panel.add(desc, 193, 527);
		desc.setSize("589px", "93px");
		
		AbsolutePanel galleria = galleria(ann);
		galleria.setStyleName(config.getStile()+"-label");
		panel.add(galleria, 193, 249);
		
		AbsolutePanel dati_principali = importanti(ann, cat);
		dati_principali.setStyleName(config.getStile()+"-label");
		panel.add(dati_principali, 475, 214);
		
		AbsolutePanel dettagli = dettagli(ann, cat, tipo);
		dettagli.setStyleName(config.getStile()+"-label");
		panel.add(dettagli, 193, 626);
		dettagli.setSize("1025px", "201px");
		
		//MapsFactory map = MapsFactory.getMapsFactory();
		//MapWidget mappa = map.getMapsAdapter().getMapbyAddress(15, ann.geteImmobile().geteIndirizzo().toString());
		VMapsAdapter map = new VMapsAdapter();
		MapWidget mappa = map.getMapbyAddress(15, ann.geteImmobile().geteIndirizzo().toString());
		panel.add(mappa, 788, 249);
		mappa.setSize("430px", "371px");
		return panel;
	}



	private FlexTable getTable(final LinkedList<EAnnuncio> lista, final String cat, final String tipo) {
		
		FlexTable table = new FlexTable();
		if (lista == null){
			AbsolutePanel pan = new AbsolutePanel();
			Label errore = new Label("nessun risultato trovato");
			pan.add(errore);
			table.setWidget(1, 0, pan);
		}else{
			for (int i=0; i<lista.size(); i++){
				AbsolutePanel pan = new AbsolutePanel();
				Label desc = new Label();
				Label prezzo = new Label();
				Image foto = new Image();
				Label sup = new Label();
				if (cat.equals("residenziale")){
					if (tipo.equals("in vendita")){
						//TODO
					}else{
						//TODO
					}
				}else{
					if(tipo.equals("garage")){
						desc.setText(lista.get(i).getDescrizione());
						prezzo.setText("prezzo : "+String.valueOf(lista.get(i).geteGarage().getPrezzo()));
						foto.setUrl(lista.get(i).getFoto()[1]);
						foto.setSize("100px", "100px");
						sup.setText("superficie : "+String.valueOf(lista.get(i).geteGarage().getSuperficie()));
					}else{
						desc.setText(lista.get(i).getDescrizione());
						prezzo.setText("prezzo : "+String.valueOf(lista.get(i).geteTerreni().getPrezzo()));
						foto.setUrl(lista.get(i).getFoto()[1]);
						foto.setSize("50px", "50px");
						sup.setText("superficie : "+String.valueOf(lista.get(i).geteTerreni().getSuperficie()));
					}
				}
				final int id = lista.get(i).getID();
				Button salva = new Button("salva");
				salva.addClickHandler(new ClickHandler(){

					@Override
					public void onClick(ClickEvent event) {
						CConsulta consulta = CConsulta.getCConsulta();
						consulta.salva(id);
					}
					
				});
				pan.add(salva);
				pan.add(sup);
				sup.setSize("168px", "18px");
				pan.add(foto);
				pan.add(prezzo);
				prezzo.setSize("168px", "18px");
				pan.add(desc);
				desc.setSize("322px", "18px");
				pan.setTitle(String.valueOf(lista.get(i).getID()));
				pan.setStyleName(Config.getConfig().getStile()+"-table");
				table.setWidget(i, 0, pan);
			}
		}
		return table;
	}
	
	
	
	private AbsolutePanel getRicerca(final String cat,final String tipo, final String reg, final int idreg) {
		AbsolutePanel affinaRicerca = new AbsolutePanel();
		affinaRicerca.setSize("288px", "517px");
		VerticalPanel verticalPanel = new VerticalPanel();
		affinaRicerca.add(verticalPanel, 0, 0);
		verticalPanel.setSize("98px", "518px");
		VerticalPanel verticalPanel_1 = new VerticalPanel();
		affinaRicerca.add(verticalPanel_1, 97, 0);
		verticalPanel_1.setSize("191px", "518px");
		Label regione = new Label("regione");
		verticalPanel.add(regione);
		Label provincia = new Label("provincia");
		verticalPanel.add(provincia);
		Label citta = new Label("citta");
		verticalPanel.add(citta);
		ListBox cregione = new ListBox();
		cregione.addItem(reg,reg);
		cregione.setEnabled(false);
		cregione.setWidth("100px");
		verticalPanel_1.add(cregione);
		final ListBox cprovincia = new ListBox();
		verticalPanel_1.add(cprovincia);
		cprovincia.setWidth("100px");
		cprovincia.addItem("-provincia-", "null");
		final ListBox ccitta = new ListBox();
		verticalPanel_1.add(ccitta);
		ccitta.setEnabled(false);
		ccitta.addItem("-citta-","null");
		ccitta.setWidth("100px");
		getProvincie(idreg, cprovincia);
		cprovincia.addChangeHandler(new ChangeHandler(){

			@Override
			public void onChange(ChangeEvent event) {
				int pro = Integer.parseInt(cprovincia.getValue(cprovincia.getSelectedIndex()));
				if (pro != 0){
					getComuni(pro, ccitta);
				}else{
					ccitta.setEnabled(false);
					ccitta.setSelectedIndex(0);
				}			
			}
			
		});
		Label categoria = new Label("categoria");
		verticalPanel.add(categoria);
		final ListBox ccategoria = new ListBox();
		verticalPanel_1.add(ccategoria);
		ccategoria.setSize("100px", "22px");
		ccategoria.addItem(cat,cat);
		ccategoria.setEnabled(false);
		if (cat.equals("residenziale")){
			//TODO
		}else{
			Label prezzo = new Label("prezzo");
			verticalPanel.add(prezzo);
			HorizontalPanel horizontalPanel = new HorizontalPanel();
			verticalPanel_1.add(horizontalPanel);
			horizontalPanel.setWidth("183px");
			Label da1 = new Label("da");
			horizontalPanel.add(da1);
			final IntegerBox prezzoda = new IntegerBox();
			horizontalPanel.add(prezzoda);
			prezzoda.setSize("53px", "15px");
			Label a1 = new Label("a");
			horizontalPanel.add(a1);
			final IntegerBox prezzoa = new IntegerBox();
			horizontalPanel.add(prezzoa);
			prezzoa.setSize("53px", "15px");
			final ListBox cposti = new ListBox();
			final ListBox ccolture = new ListBox();
			final ListBox cproprieta = new ListBox();
			if (tipo.equals("garage")){
				Label posti = new Label("posti auto");
				verticalPanel.add(posti);
				verticalPanel_1.add(cposti);
				cposti.setWidth("100px");
				cposti.addItem("-posti auto-","0");
				cposti.addItem("1","1");
				cposti.addItem("2","2");
				cposti.addItem("3","3");
				cposti.addItem("4","4");
			}else{
				Label colture = new Label("colture");
				verticalPanel.add(colture);
				verticalPanel_1.add(ccolture);
				ccolture.setWidth("100px");
				ccolture.addItem("-colture-","0");
				ccolture.addItem("prima","prima");
				ccolture.addItem("prima","prima");
				Label proprieta = new Label("posti auto");
				verticalPanel.add(proprieta);
				verticalPanel_1.add(cproprieta);
				cproprieta.setWidth("100px");
				cproprieta.addItem("-proprieta-","0");
				cproprieta.addItem("p1","p1");
				cproprieta.addItem("p2","p2");
		}
		Button raffinaCerca = new Button("CERCA");
		affinaRicerca.add(raffinaCerca, 37, 514);
		raffinaCerca.setSize("147px", "32px");
		raffinaCerca.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CConsulta consulta =  CConsulta.getCConsulta();
				int pos = 0;
				String colt = null;
				String prop = null;
				int prea = 0;
				int preda = 0;
				String pro = null;
				String cit = null;
				pro = cprovincia.getValue(cprovincia.getSelectedIndex());
				cit = ccitta.getValue(ccitta.getSelectedIndex());
				preda = prezzoda.getValue();
				prea = prezzoa.getValue();
				if(tipo.equals("garage")){
					pos =  Integer.parseInt(cposti.getValue(cposti.getSelectedIndex()));
					consulta.cercaGarage(reg, idreg, pro, cit, prea, preda, 0, 0, pos, cat, tipo);
				}else{
					colt = ccolture.getValue(ccolture.getSelectedIndex());
					prop = cproprieta.getValue(cproprieta.getSelectedIndex());
					consulta.cercaTerreni(reg, idreg, pro, cit, prea, preda, 0, 0, prop, colt, cat, tipo);
				}
			}
		});
		}
	return affinaRicerca;
	}

	private void getComuni(int id, final ListBox l){
		l.clear();
		l.setEnabled(true);
		l.addItem("-citta-","0");
		gsa.cercaComuni(id, new AsyncCallback<LinkedList<String>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<String> result) {
				for (int i=0; i<result.size(); i++){
					l.addItem(result.get(i).toLowerCase(),result.get(i).toLowerCase()); 
				}
			}
		});
	}
	
	private void getProvincie(int id, final ListBox l) {
		l.clear();
		l.setEnabled(true);
		l.addItem("-provincia-", "0");
		gsa .cercaProvincie(id,new AsyncCallback<LinkedList<Provincie>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<Provincie> result) {
				for (int i=0; i<result.size(); i++){
					l.addItem(result.get(i).getNomeprovincia().toLowerCase(),String.valueOf(result.get(i).getIdprovincia()));
				}
				
			}
			
		});
	}
	

	private AbsolutePanel galleria(final EAnnuncio ann){
		AbsolutePanel galleria = new AbsolutePanel();
		galleria.setSize("589px", "272px");
		final Image image = new Image(ann.getFoto()[1]);
		galleria.add(image, 121, 10);
		image.setSize("343px", "252px");
		final Button avanti = new Button("Avanti");
		avanti.setSize("95px", "252px");
		Image image_1 = new Image("frecciasx.png");
		image_1.setStyleName("image-click");
		galleria.add(image_1, 10, 85);
		image_1.setSize("100px", "100px");
		
		Image image_2 = new Image("frecciadx.png");
		galleria.add(image_2, 479, 85);
		image_2.setSize("100px", "100px");
		image_2.setStyleName("image-click");
	
		image_2.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				count  ++;
				if (ann.getFoto().length <= count){
					count = 1;
				}
				image.setUrl(ann.getFoto()[count]);
			}
		});
		
		image_1.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				count--;
				if (count < 1){
					count = ann.getFoto().length-1;
				}
				image.setUrl(ann.getFoto()[count]);
			}
		});
		return galleria;
		
	}

	private AbsolutePanel dettagli(EAnnuncio ann, String cat, String tipo){
		AbsolutePanel dettagli_1 = new AbsolutePanel();
		Label l1 = new Label();
		Label l2 = new Label();
		Label l3 = new Label();
		Label l4 = new Label();
		Label l5 = new Label();
		Label l6 = new Label();
		Label l7 = new Label();
		Label l8 = new Label();
		Label l9 = new Label();
		Label l10 = new Label();
		Label l11 = new Label();
		Label l12 = new Label();
		Label l13 = new Label();
		Label l14 = new Label();
		Label l15 = new Label();
	    if (cat.equals("commerciale")){
			if (tipo.equals("garage")){
				l1.setText("posti auto :"+String.valueOf(ann.geteGarage().getPosti_auto()));
			}else{
				l1.setText("colture :"+ann.geteTerreni().getColture());
				l2.setText("proprieta : "+ann.geteTerreni().getProprieta());
			}
		}else{
			l1.setText("camere :"+String.valueOf(ann.geteResidenziale().getCamere()));
			l2.setText("stato : "+ann.geteResidenziale().getStato());
			l3.setText("locali :"+String.valueOf(ann.geteResidenziale().getLocali()));
			l4.setText("piano :"+String.valueOf(ann.geteResidenziale().getPiano()));
			l5.setText("totale piani :"+String.valueOf(ann.geteResidenziale().getTotale_piani()));
			l6.setText("ascensore :"+String.valueOf(ann.geteResidenziale().getAscensore()));
			l7.setText("classe energetica :"+ann.geteResidenziale().getClasse_energetica());
			l8.setText("riscaldamento :"+ann.geteResidenziale().getRiscaldamento());
			l9.setText("cucina :"+ann.geteResidenziale().getCucina());
			l10.setText("garage :"+String.valueOf(ann.geteResidenziale().getGarage()));
			l11.setText("bagni :"+String.valueOf(ann.geteResidenziale().getBagni()));
			l12.setText("giardino :"+ann.geteResidenziale().getGiardino());
			l13.setText("balcone :"+ann.geteResidenziale().getBalcone());
			if (tipo.equals("in affitto")){
				l14.setText("arredato :"+ann.geteAffitto().getAscensore());
				l15.setText("contratto :"+ann.geteAffitto().getContratto());
			}
		}
		dettagli_1.add(l1, 0, 0);
		l1.setSize("50%", "12%");
		dettagli_1.add(l2, 0, 29);
		l2.setSize("50%", "12%");
		dettagli_1.add(l3, 0, 58);
		l3.setSize("50%", "12%");
		dettagli_1.add(l4, 0, 87);
		l4.setSize("50%", "12%");
		dettagli_1.add(l5, 0, 116);
		l5.setSize("50%", "12%");
		dettagli_1.add(l6, 0, 145);
		l6.setSize("50%", "12%");
		dettagli_1.add(l7, 0, 163);
		l7.setSize("50%", "12%");
		dettagli_1.add(l8, 282, 0);
		l8.setSize("50%", "12%");
		dettagli_1.add(l9, 282, 29);
		l9.setSize("50%", "12%");
		dettagli_1.add(l10, 282, 58);
		l10.setSize("50%", "12%");
		dettagli_1.add(l11, 282, 87);
		l11.setSize("50%", "12%");
		dettagli_1.add(l12, 282, 116);
		l12.setSize("50%", "12%");
		dettagli_1.add(l13, 282, 145);
		l13.setSize("50%", "12%");
		dettagli_1.add(l14, 282, 163);
		l14.setSize("50%", "12%");
		dettagli_1.add(l15, 0, 176);
		l15.setSize("50%", "12%");
		return dettagli_1;
	}

	private AbsolutePanel importanti(EAnnuncio ann, String cat){
		AbsolutePanel dati_principali = new AbsolutePanel();
		dati_principali.setSize("743px", "29px");
		Label superficie = new Label();
		Label prezzo = new Label();
		Label indirizzo = new Label();
		superficie.setText(String.valueOf(ann.geteImmobile().getSuperficie())+" mq");
		prezzo.setText(String.valueOf(ann.geteImmobile().getPrezzo())+" euro");	
		indirizzo.setText(ann.geteImmobile().geteIndirizzo().toString());
		dati_principali.add(superficie, 0, 0);
		superficie.setSize("109px", "16px");
		dati_principali.add(prezzo, 115, 0);
		prezzo.setSize("125px", "16px");
		dati_principali.add(indirizzo, 246, 0);
		indirizzo.setSize("424px", "16px");
		return dati_principali;
	}
}
