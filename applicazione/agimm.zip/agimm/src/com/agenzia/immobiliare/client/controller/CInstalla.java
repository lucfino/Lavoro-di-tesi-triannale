package com.agenzia.immobiliare.client.controller;

import com.agenzia.immobiliare.client.Installa;
import com.agenzia.immobiliare.client.InstallaAsync;
import com.agenzia.immobiliare.client.view.VHome;
import com.agenzia.immobiliare.client.view.VInstalla;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;

public class CInstalla {
	
	private InstallaAsync ia = GWT.create(Installa.class);
	
	private CInstalla(){}
	
	private static CInstalla installa;
	
	private static int i = 0;
	
	public static CInstalla getCInstalla(){
		if (i==0){
			installa = new CInstalla();
		}
		return installa;
	}
	
	public void hello(){
		VInstalla installa = VInstalla.getVInstalla();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = installa.getHello();
		home.impostaPagina(panel);
	}
	
	public void passo1(){
		VInstalla installa= VInstalla.getVInstalla();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = installa.getPasso1();
		home.impostaPagina(panel);
	}

	public void passo2(String[] config ) {
		VInstalla installa= VInstalla.getVInstalla();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = installa.getPasso2(config);
		home.impostaPagina(panel);
	}

	public void passo3(String[] config) {
		VInstalla installa= VInstalla.getVInstalla();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = installa.getPasso3(config);
		home.impostaPagina(panel);
	}

	public void passo4(String[] config) {
		VInstalla installa= VInstalla.getVInstalla();
		CHome home = CHome.getCHome();
		AbsolutePanel panel = installa.getPasso4(config);
		home.impostaPagina(panel);
	}

	public void installa(String[] config) {
		ia.installa(config, new AsyncCallback<String>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(String result) {
				if (result.equals("")){
					CHome home = CHome.getCHome();
					VHome vhome = VHome.getVHome();
					AbsolutePanel panel = vhome.getPanel();
					home.impostaPagina(panel);
				}else{
					Window.alert(result);
				}
			}
			
		});
		
	}
	
	public void cambiaXML() {
		
	}
	

}
