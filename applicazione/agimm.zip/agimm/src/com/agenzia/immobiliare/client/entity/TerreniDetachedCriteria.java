/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class TerreniDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression ID;
	public final IntegerExpression superficie;
	public final IntegerExpression prezzo;
	public final StringExpression proprieta;
	public final StringExpression colture;
	
	public TerreniDetachedCriteria() {
		super(com.agenzia.immobiliare.client.entity.Terreni.class, com.agenzia.immobiliare.client.entity.TerreniCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		superficie = new IntegerExpression("superficie", this.getDetachedCriteria());
		prezzo = new IntegerExpression("prezzo", this.getDetachedCriteria());
		proprieta = new StringExpression("proprieta", this.getDetachedCriteria());
		colture = new StringExpression("colture", this.getDetachedCriteria());
	}
	
	public TerreniDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, com.agenzia.immobiliare.client.entity.TerreniCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		superficie = new IntegerExpression("superficie", this.getDetachedCriteria());
		prezzo = new IntegerExpression("prezzo", this.getDetachedCriteria());
		proprieta = new StringExpression("proprieta", this.getDetachedCriteria());
		colture = new StringExpression("colture", this.getDetachedCriteria());
	}
	
	public EIndirizzoDetachedCriteria createEIndirizzoCriteria() {
		return new EIndirizzoDetachedCriteria(createCriteria("eIndirizzo"));
	}
	
	public Terreni uniqueTerreni(PersistentSession session) {
		return (Terreni) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Terreni[] listTerreni(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Terreni[]) list.toArray(new Terreni[list.size()]);
	}
}

