package com.agenzia.immobiliare.client.view;

import java.util.LinkedList;
import java.util.List;

import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.google.gwt.maps.client.MapOptions;
import com.google.gwt.maps.client.MapTypeId;
import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.base.HasLatLng;
import com.google.gwt.maps.client.base.InfoWindow;
import com.google.gwt.maps.client.event.EventCallback;
import com.google.gwt.maps.client.event.impl.EventImpl;
import com.google.gwt.maps.client.geocoder.Geocoder;
import com.google.gwt.maps.client.geocoder.GeocoderCallback;
import com.google.gwt.maps.client.geocoder.GeocoderRequest;
import com.google.gwt.maps.client.geocoder.HasGeocoderRequest;
import com.google.gwt.maps.client.geocoder.HasGeocoderResult;
import com.google.gwt.maps.client.overlay.Marker;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;

public class VMapsAdapter implements IVMapsAdapter{
	
	public VMapsAdapter(){}
	
	public MapWidget getMapbyAddress(int zoom, String ind){
		MapOptions options = new MapOptions();
		options.setZoom(zoom);
	    options.setMapTypeId(new MapTypeId().getRoadmap());
	    options.setDraggable(true);
	    options.setNavigationControl(true);
	    options.setMapTypeControl(true);
	    options.setScrollwheel(true);
	    final MapWidget map = new MapWidget(options);
	    Geocoder geo = new Geocoder();
	    HasGeocoderRequest req = new GeocoderRequest();
	    req.setAddress(ind);
	    geo.geocode(req, new GeocoderCallback(){

			@Override
			public void callback(List<HasGeocoderResult> responses, String status) {
				if (status.equals("OK")){
					HasGeocoderResult res  = responses.get(0);
					HasLatLng gLatLng = res.getGeometry().getLocation();
					final Marker marker = new Marker();
					marker.setPosition(gLatLng);
			        marker.setMap(map.getMap());
			        marker.setClickable(true);
					map.getMap().setCenter(gLatLng);					
				}else{
					 Window.alert("Geocoder failed with response : " + status);
				}
			}
	    	
	    });
		return map;
	}

	public MapWidget getMapbyList(int zoom, LinkedList<EAnnuncio> l, final String cat, final String tipo) {
		MapOptions options = new MapOptions();
		options.setZoom(zoom);
	    options.setMapTypeId(new MapTypeId().getRoadmap());
	    options.setDraggable(true);
	    options.setNavigationControl(true);
	    options.setMapTypeControl(true);
	    options.setScrollwheel(true);
	    final MapWidget map = new MapWidget(options);
	    for (int i=0; i<l.size();i++){
	    	final EAnnuncio ann = l.get(i);
		    Geocoder geo = new Geocoder();
		    HasGeocoderRequest req = new GeocoderRequest();
		    req.setAddress(l.get(i).geteImmobile().geteIndirizzo().toString());
		    geo.geocode(req, new GeocoderCallback(){
	
				@Override
				public void callback(List<HasGeocoderResult> responses, String status) {
					if (status.equals("OK")){
						HasGeocoderResult res  = responses.get(0);
						HasLatLng gLatLng = res.getGeometry().getLocation();
						
						final Marker marker = new Marker();
						marker.setPosition(gLatLng);
				        marker.setMap(map.getMap());
				        marker.setClickable(true);
				        final InfoWindow info = new InfoWindow();
				        AbsolutePanel pan = new AbsolutePanel();
						Label lbl = new Label(ann.getTitolo());
						Image im = new Image(ann.getFoto()[1]);
						im.setSize("50px","50px");
						pan.add(lbl);
						pan.add(im);
						
						info.setContent(pan.getElement().getInnerHTML());
						EventImpl event = new EventImpl();
						event.addListener(marker.getJso(), "click", new EventCallback(){

							@Override
							public void callback() {
								 info.open(map.getMap(), marker);
								
							}
							
						});

				        map.getMap().setCenter(gLatLng);
					}else{
						 Window.alert("Geocoder failed with response : " + status);
					}
				}
		    	
		    });
	    }

		return map;
	}
	
	
	
	
}
