/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public abstract class EImmobile implements Serializable {
	public EImmobile() {
	}
	
	public EImmobile(EIndirizzo ind, int sup, int pre){
		this.eIndirizzo=ind;
		this.prezzo=pre;
		this.superficie=sup;
	}
	
	private int ID;
	
	private com.agenzia.immobiliare.client.entity.EIndirizzo eIndirizzo;
	
	private int superficie;
	
	private int prezzo;
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setSuperficie(int value) {
		this.superficie = value;
	}
	
	public int getSuperficie() {
		return superficie;
	}
	
	public void setPrezzo(int value) {
		this.prezzo = value;
	}
	
	public int getPrezzo() {
		return prezzo;
	}
	
	public void seteIndirizzo(com.agenzia.immobiliare.client.entity.EIndirizzo value) {
		this.eIndirizzo = value;
	}
	
	public com.agenzia.immobiliare.client.entity.EIndirizzo geteIndirizzo() {
		return eIndirizzo;
	}
	
	public String toString() {
		return String.valueOf(getID());
	}
	
}
