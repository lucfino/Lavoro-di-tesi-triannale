/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class AgenziaDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression ID;
	public final StringExpression indirizzo;
	public final StringExpression nome;
	public final StringExpression fax;
	public final StringExpression username;
	public final StringExpression password;
	public final StringExpression email;
	public final StringExpression logo;
	public final IntegerExpression cellulare;
	public final StringExpression descrizione;
	public final IntegerExpression telefono;
	
	public AgenziaDetachedCriteria() {
		super(com.agenzia.immobiliare.client.entity.Agenzia.class, com.agenzia.immobiliare.client.entity.AgenziaCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		indirizzo = new StringExpression("indirizzo", this.getDetachedCriteria());
		nome = new StringExpression("nome", this.getDetachedCriteria());
		fax = new StringExpression("fax", this.getDetachedCriteria());
		username = new StringExpression("username", this.getDetachedCriteria());
		password = new StringExpression("password", this.getDetachedCriteria());
		email = new StringExpression("email", this.getDetachedCriteria());
		logo = new StringExpression("logo", this.getDetachedCriteria());
		cellulare = new IntegerExpression("cellulare", this.getDetachedCriteria());
		descrizione = new StringExpression("descrizione", this.getDetachedCriteria());
		telefono = new IntegerExpression("telefono", this.getDetachedCriteria());
	}
	
	public AgenziaDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, com.agenzia.immobiliare.client.entity.AgenziaCriteria.class);
		ID = new IntegerExpression("ID", this.getDetachedCriteria());
		indirizzo = new StringExpression("indirizzo", this.getDetachedCriteria());
		nome = new StringExpression("nome", this.getDetachedCriteria());
		fax = new StringExpression("fax", this.getDetachedCriteria());
		username = new StringExpression("username", this.getDetachedCriteria());
		password = new StringExpression("password", this.getDetachedCriteria());
		email = new StringExpression("email", this.getDetachedCriteria());
		logo = new StringExpression("logo", this.getDetachedCriteria());
		cellulare = new IntegerExpression("cellulare", this.getDetachedCriteria());
		descrizione = new StringExpression("descrizione", this.getDetachedCriteria());
		telefono = new IntegerExpression("telefono", this.getDetachedCriteria());
	}
	
	public Agenzia uniqueAgenzia(PersistentSession session) {
		return (Agenzia) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Agenzia[] listAgenzia(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Agenzia[]) list.toArray(new Agenzia[list.size()]);
	}
}

