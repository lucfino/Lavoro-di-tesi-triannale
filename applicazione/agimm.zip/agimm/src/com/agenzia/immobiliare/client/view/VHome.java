package com.agenzia.immobiliare.client.view;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.Indirizzo;
import com.agenzia.immobiliare.client.IndirizzoAsync;
import com.agenzia.immobiliare.client.Utility;
import com.agenzia.immobiliare.client.UtilityAsync;
import com.agenzia.immobiliare.client.controller.CConsulta;
import com.agenzia.immobiliare.client.controller.CGestisci;
import com.agenzia.immobiliare.client.controller.CHome;
import com.agenzia.immobiliare.client.entity.Provincie;
import com.agenzia.immobiliare.client.entity.Regioni;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.shared.Config;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.FlexTable;

public class VHome{
	
	private static VHome home;
	
	
	public static VHome getVHome(){
		if (home == null){
			home = new VHome();
		}
		return home;
	}
	
	private VHome(){}

	private IndirizzoAsync gsa = GWT.create(Indirizzo.class);
	
	private UtilityAsync ua = GWT.create(Utility.class);
	
	public AbsolutePanel getPanel(){
		final Config config = Config.getConfig();
		
		final AbsolutePanel panel = new AbsolutePanel();
		panel.setSize("1440px", "800px");
		panel.setStyleName(config.getStile());
		
		AbsolutePanel ricerca = cercaHome();
		panel.add(ricerca,193,218);
		ricerca.setSize("719px", "347px");
		
		AbsolutePanel contattaci = new AbsolutePanel();
		contattaci.setStyleName(config.getStile()+"-label");
		panel.add(contattaci, 193, 595);
		contattaci.setSize("390px", "175px");
		Label indirizzo = new Label("indirizzo : "+config.getIndirizzo());
		contattaci.add(indirizzo, 10, 41);
		indirizzo.setSize("370px", "17px");
		Label email = new Label("email : "+config.getEmail());
		contattaci.add(email, 10, 75);
		email.setSize("370px", "17px");
		Label contatti = new Label("CONTATTI");
		contatti.setStyleName(config.getStile()+"-titolo");
		contattaci.add(contatti, 10, 10);
		contatti.setSize("386px", "16px");
		Label fax = new Label("fax : "+config.getFax());
		contattaci.add(fax, 10, 109);
		fax.setSize("370px", "17px");
		Label telefono = new Label("telefono : "+config.getTelefono());
		contattaci.add(telefono, 10, 138);
		telefono.setSize("370px", "17px");
		
		AbsolutePanel absolutePanel = new AbsolutePanel();
		absolutePanel.setStyleName(config.getStile()+"-label");
		panel.add(absolutePanel, 589, 595);
		absolutePanel.setSize("323px", "175px");
		Label chiSiamo = new Label("CHI SIAMO");
		chiSiamo.setStyleName(config.getStile()+"-titolo");
		absolutePanel.add(chiSiamo, 10, 10);
		chiSiamo.setSize("228px", "16px");
		Label descrizione = new Label(config.getDesc());
		absolutePanel.add(descrizione, 10, 32);
		descrizione.setSize("303px", "133px");
		
		final FlexTable bacheca = new FlexTable();
		panel.add(bacheca, 948, 218);
		bacheca.setSize("257px", "67px");
		bacheca.setText(0, 0, "BACHECA");
		bacheca.addStyleName(config.getStile()+"-label");
		
		AbsolutePanel absolutePanel_1 = getLogin();
		panel.add(absolutePanel_1, 191, 20);
		absolutePanel_1.setSize("1032px", "188px");
		
		
		ua.carica(new AsyncCallback<LinkedList<EAnnuncio>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(LinkedList<EAnnuncio> result) {
				for (int i=0; i<result.size(); i++){
					Label l = new Label(result.get(i).getTitolo());
					Image im = new Image(result.get(i).getFoto()[1]);
					im.setSize("50px", "50px");
					l.setTitle(String.valueOf(result.get(i).getID()));
					AbsolutePanel panel = new AbsolutePanel();
					panel.add(l);
					panel.add(im);
					panel.setStyleName(config.getStile()+"-table");
					bacheca.setWidget(i+1, 0, panel);
				}
				
			}
			
		});
		bacheca.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				//int index = bacheca.getCellForEvent(event).getRowIndex();
				//int id = Integer.parseInt(bacheca.getWidget(index, 0).getTitle());
				//CConsulta consulta =  CConsulta.getCConsulta();
				//consulta.seleziona(id, cat, tipo);
				
			}
			
		});
		
		return panel;
	}
	

	public AbsolutePanel cercaHome(){
		Config config = Config.getConfig();
		AbsolutePanel ricerca_1 = new AbsolutePanel();
		ricerca_1.setStyleName(config.getStile()+"-panel");
		final Image image = new Image("italia.png");
		ricerca_1.add(image, 285, 0);
		image.setSize("344px", "340px");
		final Button cerca = new Button("cerca");
		cerca.setEnabled(false);
		ricerca_1.add(cerca, 52, 285);
		cerca.setSize("140px", "35px");
		final ListBox tipologia = new ListBox();
		ricerca_1.add(tipologia, 42, 152);
		tipologia.setSize("163px", "22px");
		tipologia.addItem("residenziale","residenziale");
		tipologia.addItem("commerciale","commerciale");
		
		final VerticalPanel verticalPanel = new VerticalPanel();
		ricerca_1.add(verticalPanel, 42, 199);
		verticalPanel.setSize("140px", "55px");
		final RadioButton tipo1 = new RadioButton("tipologia", "in vendita");
		verticalPanel.add(tipo1);
		tipo1.setValue(true);
		final RadioButton tipo2 = new RadioButton("tipologia", "in affitto");
		verticalPanel.add(tipo2);
		final RadioButton tipo3 = new RadioButton("tipologia", "garage");
		verticalPanel.add(tipo3);
		tipo3.setVisible(false);
		final RadioButton tipo4 = new RadioButton("tipologia", "terreni");
		verticalPanel.add(tipo4);
		tipo4.setVisible(false);
		
		final ListBox regione = getRegioni();
		ricerca_1.add(regione, 42, 10);
		regione.setSize("163px", "22px");
		final ListBox provincia = new ListBox();
		ricerca_1.add(provincia, 42, 57);
		provincia.addItem("-provincia-","0");
		provincia.setEnabled(false);
		provincia.setSize("163px", "22px");
		final ListBox citta = new ListBox();
		ricerca_1.add(citta, 42, 102);
		citta.addItem("-citta-","0");
		citta.setEnabled(false);
		citta.setSize("163px", "22px");
		regione.addChangeHandler(new ChangeHandler(){
			@Override
			public void onChange(ChangeEvent event) {
				int reg = Integer.parseInt(regione.getValue(regione.getSelectedIndex()));
				if(reg != 0){
					getProvincie(reg, provincia);
					image.setUrl(regione.getItemText(regione.getSelectedIndex())+".png");
					cerca.setEnabled(true);
				}else{
					image.setUrl("italia.png");
					provincia.setEnabled(false);
					provincia.setSelectedIndex(0);
					citta.setEnabled(false);
					citta.setSelectedIndex(0);
					cerca.setEnabled(false);
				}
			}
		});
		provincia.addChangeHandler(new ChangeHandler(){
			@Override
			public void onChange(ChangeEvent event) {
				int pro = Integer.parseInt(provincia.getValue(provincia.getSelectedIndex()));
				if (pro != 0){
					getComuni(pro, citta);
				}else{
					citta.setEnabled(false);
					citta.setSelectedIndex(0);
				}
			}
		});
		tipologia.addChangeHandler(new ChangeHandler(){

			@Override
			public void onChange(ChangeEvent event) {
				if (tipologia.getValue(tipologia.getSelectedIndex()).equals("commerciale")){
					tipo1.setVisible(false);
					tipo2.setVisible(false);
					tipo3.setVisible(true);
					tipo4.setVisible(true);
					tipo3.setValue(true);
				}else{
					tipo3.setVisible(false);
					tipo4.setVisible(false);
					tipo1.setVisible(true);
					tipo2.setVisible(true);
					tipo1.setValue(true);
				}
				
			}
			
		});
		cerca.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				String reg = regione.getItemText(regione.getSelectedIndex());
				String pro = "";
				String cit = "";
				if (!provincia.getValue(provincia.getSelectedIndex()).equals("0")){
					pro = provincia.getItemText(provincia.getSelectedIndex());
				}
				if(citta.getValue(citta.getSelectedIndex()).equals("0")){
					cit = citta.getItemText(citta.getSelectedIndex());
				}
				String cat = tipologia.getItemText(tipologia.getSelectedIndex());
				String tipo = null;
				if(tipo1.getValue()){
					tipo= tipo1.getText();
				}
				if(tipo2.getValue()){
					tipo= tipo2.getText();
				}
				if(tipo3.getValue()){
					tipo= tipo3.getText();
				}
				if(tipo4.getValue()){
					tipo= tipo4.getText();
				}
				int idreg = Integer.parseInt(regione.getValue(regione.getSelectedIndex()));
				CConsulta consulta = CConsulta.getCConsulta();
				if (cat.equals("residenziale")){
					if (tipo.equals("in vendita")){
						//TODO
					}else{
						//TODO
					}
				}else{
					if (tipo.equals("garage")){
						consulta.cercaGarage(reg, idreg, pro, cit, 0, 0, 0, 0, 0, cat, tipo);
					}else{
						consulta.cercaTerreni(reg, idreg, pro, cit, 0, 0, 0, 0, null, null, cat, tipo);
					}
				}
				
			}
		});
		return ricerca_1;
	}
	
	private ListBox getRegioni() {
		final ListBox l_1 = new ListBox();
		l_1.addItem("-regione-", "0");
		gsa.cercaRegioni(new AsyncCallback<Regioni[]>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(Regioni[] result) {
				for (int i=1; i<result.length; i++){
					l_1.addItem(result[i].getNomeregione().toLowerCase(),String.valueOf(result[i].getIdregioni()));
				}
				
			}
			
		});
		return l_1;
	}
	
	
	public AbsolutePanel getLogin() {
		final AbsolutePanel absolutePanel_1 = new AbsolutePanel();
		Config config = Config.getConfig();
		
		Label AgenziaImmobiliare = new Label(config.getNome());
		absolutePanel_1.add(AgenziaImmobiliare, 186, 58);
		AgenziaImmobiliare.setStyleName("stile1-home");
		AgenziaImmobiliare.setSize("528px", "65px");
		AgenziaImmobiliare.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				CHome home = CHome.getCHome();
				AbsolutePanel panel = getPanel();
				home.impostaPagina(panel);
			}
			
		});
		
		Image logo = new Image(config.getLogo());
		absolutePanel_1.add(logo,0,0);
		logo.setSize("180px", "185px");
		
		ua.loggato(new AsyncCallback<Boolean>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
				
			}

			@Override
			public void onSuccess(Boolean result) {
				final AbsolutePanel absolutePanel_1_1 = new AbsolutePanel();
				absolutePanel_1.add(absolutePanel_1_1, 774, 0);
				absolutePanel_1_1.setSize("248px", "185px");
				if (result){
					Label benvenuto = new Label("benvenuto admin");
					absolutePanel_1_1.add(benvenuto, 10, 10);
					benvenuto.setSize("228px", "18px");
					Button logout = new Button("LOGOUT");
					absolutePanel_1_1.add(logout, 82, 122);
					logout.addClickHandler(new ClickHandler(){

						@Override
						public void onClick(ClickEvent event) {
							CConsulta consulta =  CConsulta.getCConsulta();
							consulta.logout();
						}
						
					});
					Button privata = new Button("AREA PRIVATA");
					privata.setText("ACCEDI ALL'AREA PRIVATA");
					absolutePanel_1_1.add(privata, 23, 51);
					privata.setSize("199px", "40px");
					privata.addClickHandler(new ClickHandler(){

						@Override
						public void onClick(ClickEvent event) {
							CGestisci gestisci = CGestisci.getCGestisci();
							gestisci.homeAdmin();
						}
						
					});
				}else{
					Label username = new Label("username :");
					absolutePanel_1_1.add(username, 10, 10);
					final TextBox tusername = new TextBox();
					absolutePanel_1_1.add(tusername, 10, 34);
					tusername.setSize("160px", "13px");
					Label password = new Label("password :");
					absolutePanel_1_1.add(password, 10, 65);
					password.setSize("65px", "18px");
					final PasswordTextBox tpassword = new PasswordTextBox();
					absolutePanel_1_1.add(tpassword, 10, 89);
					tpassword.setSize("160px", "13px");
					Button accedi = new Button("ACCEDI");
					absolutePanel_1_1.add(accedi, 10, 120);
					accedi.setSize("170px", "32px");
					accedi.addClickHandler(new ClickHandler(){
					
						@Override
						public void onClick(ClickEvent event) {
							CConsulta consulta =  CConsulta.getCConsulta();
							String user = tusername.getValue();
							String pass = tpassword.getValue();
							consulta.accedi(user, pass);
						}
					});
				}
			}
			
		});
		return absolutePanel_1;
	}
	
	private void getComuni(int id, final ListBox l){
		l.clear();
		l.setEnabled(true);
		l.addItem("-citta-","0");
		gsa.cercaComuni(id, new AsyncCallback<LinkedList<String>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<String> result) {
				for (int i=0; i<result.size(); i++){
					l.addItem(result.get(i).toLowerCase(),result.get(i).toLowerCase()); 
				}
			}
		});
	}
	
	private void getProvincie(int id, final ListBox l) {
		l.clear();
		l.setEnabled(true);
		l.addItem("-provincia-", "0");
		gsa.cercaProvincie(id,new AsyncCallback<LinkedList<Provincie>>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}

			@Override
			public void onSuccess(LinkedList<Provincie> result) {
				for (int i=0; i<result.size(); i++){
					l.addItem(result.get(i).getNomeprovincia().toLowerCase(),String.valueOf(result.get(i).getIdprovincia()));
				}
				
			}
			
		});
	}
	
	public void stampa(AbsolutePanel panel){
		RootLayoutPanel.get().clear();
		RootLayoutPanel.get().add(panel);
	}
}

