/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class AgenziaCriteria extends AbstractORMCriteria {
	public final IntegerExpression ID;
	public final StringExpression indirizzo;
	public final StringExpression nome;
	public final StringExpression fax;
	public final StringExpression username;
	public final StringExpression password;
	public final StringExpression email;
	public final StringExpression logo;
	public final IntegerExpression cellulare;
	public final StringExpression descrizione;
	public final IntegerExpression telefono;
	
	public AgenziaCriteria(Criteria criteria) {
		super(criteria);
		ID = new IntegerExpression("ID", this);
		indirizzo = new StringExpression("indirizzo", this);
		nome = new StringExpression("nome", this);
		fax = new StringExpression("fax", this);
		username = new StringExpression("username", this);
		password = new StringExpression("password", this);
		email = new StringExpression("email", this);
		logo = new StringExpression("logo", this);
		cellulare = new IntegerExpression("cellulare", this);
		descrizione = new StringExpression("descrizione", this);
		telefono = new IntegerExpression("telefono", this);
	}
	
	public AgenziaCriteria(PersistentSession session) {
		this(session.createCriteria(Agenzia.class));
	}
	
	public AgenziaCriteria() throws PersistentException {
		this(com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession());
	}
	
	public Agenzia uniqueAgenzia() {
		return (Agenzia) super.uniqueResult();
	}
	
	public Agenzia[] listAgenzia() {
		java.util.List list = super.list();
		return (Agenzia[]) list.toArray(new Agenzia[list.size()]);
	}
}

