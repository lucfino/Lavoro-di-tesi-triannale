package com.agenzia.immobiliare.client;

import com.agenzia.immobiliare.client.entity.Agenzia;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface AgenziaServiceAsync{
	
	void carica(AsyncCallback<Agenzia> callback);
	
	void modifica(String ind, String nom, String fa, String user,
			String pass, String mail, String desc, int tel, AsyncCallback<Boolean> callback);

}
