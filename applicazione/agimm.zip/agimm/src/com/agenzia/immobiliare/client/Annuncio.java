package com.agenzia.immobiliare.client;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("annuncio")
public interface Annuncio extends RemoteService{
	
	EAnnuncio carica(int id);
	
	boolean inserisciGarage(EAnnuncio ann);
	
	boolean cancella(int id);
	
	LinkedList<EAnnuncio> cercaTerreni(String reg, String pro, String cit, int prea, int preda, int supa, int supda, String prop, String col);
	
	LinkedList<EAnnuncio> cercaGarage(String reg, String pro, String cit, int prea, int preda, int supa, int supda, int gar);

	LinkedList<EAnnuncio> cerca();

	boolean inserisciTerreni(EAnnuncio ann);

}
