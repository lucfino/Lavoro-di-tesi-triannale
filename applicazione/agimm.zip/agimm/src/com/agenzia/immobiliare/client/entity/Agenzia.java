/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class Agenzia implements Serializable {
	public Agenzia() {
	}
	
	public Agenzia(int id, String ind, String nom, String fax, String user, String pass, String mail, String desc, int tel){
		this.ID=id;
		this.indirizzo=ind;
		this.nome=nom;
		this.fax=fax;
		this.username=user;
		this.password=pass;
		this.email=mail;
		this.descrizione=desc;
		this.telefono=tel;
	}
	
	private int ID;
	
	private String indirizzo;
	
	private String nome;
	
	private String fax;
	
	private String username;
	
	private String password;
	
	private String email;
	
	private String logo;
	
	private int cellulare;
	
	private String descrizione;
	
	private int telefono;
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setIndirizzo(String value) {
		this.indirizzo = value;
	}
	
	public String getIndirizzo() {
		return indirizzo;
	}
	
	public void setNome(String value) {
		this.nome = value;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setFax(String value) {
		this.fax = value;
	}
	
	public String getFax() {
		return fax;
	}
	
	public void setUsername(String value) {
		this.username = value;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setPassword(String value) {
		this.password = value;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setEmail(String value) {
		this.email = value;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setLogo(String value) {
		this.logo = value;
	}
	
	public String getLogo() {
		return logo;
	}
	
	public void setCellulare(int value) {
		this.cellulare = value;
	}
	
	public int getCellulare() {
		return cellulare;
	}
	
	public void setDescrizione(String value) {
		this.descrizione = value;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public void setTelefono(int value) {
		this.telefono = value;
	}
	
	public int getTelefono() {
		return telefono;
	}
	
	public String toString() {
		return String.valueOf(getID());
	}
	
}
