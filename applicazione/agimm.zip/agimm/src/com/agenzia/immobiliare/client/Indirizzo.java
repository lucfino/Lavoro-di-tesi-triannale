package com.agenzia.immobiliare.client;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.Provincie;
import com.agenzia.immobiliare.client.entity.Regioni;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * The client side stub for the RPC service.
 */
@RemoteServiceRelativePath("indirizzo")
public interface Indirizzo extends RemoteService {
	
	Regioni[] cercaRegioni();
	
	LinkedList<Provincie> cercaProvincie(int id);
	
	LinkedList<String> cercaComuni(int id);	
	
}
