/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class EAffittoCriteria extends AbstractORMCriteria {
	public final IntegerExpression ID;
	public final IntegerExpression superficie;
	public final IntegerExpression prezzo;
	public final IntegerExpression camere;
	public final StringExpression stato;
	public final IntegerExpression locali;
	public final IntegerExpression piano;
	public final IntegerExpression totale_piani;
	public final BooleanExpression ascensore;
	public final StringExpression classe_energetica;
	public final StringExpression riscaldamento;
	public final StringExpression cucina;
	public final BooleanExpression garage;
	public final IntegerExpression bagni;
	public final StringExpression giardino;
	public final StringExpression balcone;
	
	public EAffittoCriteria(Criteria criteria) {
		super(criteria);
		ID = new IntegerExpression("ID", this);
		superficie = new IntegerExpression("superficie", this);
		prezzo = new IntegerExpression("prezzo", this);
		camere = new IntegerExpression("camere", this);
		stato = new StringExpression("stato", this);
		locali = new IntegerExpression("locali", this);
		piano = new IntegerExpression("piano", this);
		totale_piani = new IntegerExpression("totale_piani", this);
		ascensore = new BooleanExpression("ascensore", this);
		classe_energetica = new StringExpression("classe_energetica", this);
		riscaldamento = new StringExpression("riscaldamento", this);
		cucina = new StringExpression("cucina", this);
		garage = new BooleanExpression("garage", this);
		bagni = new IntegerExpression("bagni", this);
		giardino = new StringExpression("giardino", this);
		balcone = new StringExpression("balcone", this);
	}
	
	public EAffittoCriteria(PersistentSession session) {
		this(session.createCriteria(EAffitto.class));
	}
	
	public EAffittoCriteria() throws PersistentException {
		this(com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession());
	}
	
	public EIndirizzoCriteria createEIndirizzoCriteria() {
		return new EIndirizzoCriteria(createCriteria("eIndirizzo"));
	}
	
	public EAffitto uniqueEAffitto() {
		return (EAffitto) super.uniqueResult();
	}
	
	public EAffitto[] listEAffitto() {
		java.util.List list = super.list();
		return (EAffitto[]) list.toArray(new EAffitto[list.size()]);
	}
}

