package com.agenzia.immobiliare.client;

import com.agenzia.immobiliare.client.entity.Agenzia;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("agenzia")
public interface AgenziaService extends RemoteService{
	
	Agenzia carica();
	
	boolean modifica(String ind, String nom, String fa, String user,
			String pass, String mail, String desc, int tel);

}
