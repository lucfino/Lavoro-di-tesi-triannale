package com.agenzia.immobiliare.client.view;

import java.io.Serializable;
import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.google.gwt.maps.client.MapWidget;

public interface IVMapsAdapter extends Serializable{
	
	public MapWidget getMapbyAddress(int zoom, String ind);
	
	public MapWidget getMapbyList(int zoom, LinkedList<EAnnuncio> l, final String cat, final String tipo);

}
