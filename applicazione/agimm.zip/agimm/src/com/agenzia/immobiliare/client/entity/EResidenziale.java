/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class EResidenziale extends com.agenzia.immobiliare.client.entity.EImmobile implements Serializable {
	public EResidenziale() {
	}
	
	public EResidenziale(EIndirizzo ind, int sup, int pre){
		super(ind, sup, pre);
	}
	
	private int camere;
	
	private String stato;
	
	private int locali;
	
	private int piano;
	
	private int totale_piani;
	
	private boolean ascensore;
	
	private String classe_energetica;
	
	private String riscaldamento;
	
	private String cucina;
	
	private boolean garage;
	
	private int bagni;
	
	private String giardino;
	
	private String balcone;
	
	public void setCamere(int value) {
		this.camere = value;
	}
	
	public int getCamere() {
		return camere;
	}
	
	public void setStato(String value) {
		this.stato = value;
	}
	
	public String getStato() {
		return stato;
	}
	
	public void setLocali(int value) {
		this.locali = value;
	}
	
	public int getLocali() {
		return locali;
	}
	
	public void setPiano(int value) {
		this.piano = value;
	}
	
	public int getPiano() {
		return piano;
	}
	
	public void setTotale_piani(int value) {
		this.totale_piani = value;
	}
	
	public int getTotale_piani() {
		return totale_piani;
	}
	
	public void setAscensore(boolean value) {
		this.ascensore = value;
	}
	
	public boolean getAscensore() {
		return ascensore;
	}
	
	public void setClasse_energetica(String value) {
		this.classe_energetica = value;
	}
	
	public String getClasse_energetica() {
		return classe_energetica;
	}
	
	public void setRiscaldamento(String value) {
		this.riscaldamento = value;
	}
	
	public String getRiscaldamento() {
		return riscaldamento;
	}
	
	public void setCucina(String value) {
		this.cucina = value;
	}
	
	public String getCucina() {
		return cucina;
	}
	
	public void setGarage(boolean value) {
		this.garage = value;
	}
	
	public boolean getGarage() {
		return garage;
	}
	
	public void setBagni(int value) {
		this.bagni = value;
	}
	
	public int getBagni() {
		return bagni;
	}
	
	public void setGiardino(String value) {
		this.giardino = value;
	}
	
	public String getGiardino() {
		return giardino;
	}
	
	public void setBalcone(String value) {
		this.balcone = value;
	}
	
	public String getBalcone() {
		return balcone;
	}
	
	public String toString() {
		return super.toString();
	}
	
}
