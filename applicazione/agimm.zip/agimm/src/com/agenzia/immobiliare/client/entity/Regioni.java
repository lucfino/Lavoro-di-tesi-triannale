/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class Regioni implements Serializable {
	public Regioni() {
	}
	
	private int idregioni;
	
	private String nomeregione;
	
	private void setIdregioni(int value) {
		this.idregioni = value;
	}
	
	public int getIdregioni() {
		return idregioni;
	}
	
	public int getORMID() {
		return getIdregioni();
	}
	
	public void setNomeregione(String value) {
		this.nomeregione = value;
	}
	
	public String getNomeregione() {
		return nomeregione;
	}
	
	public String toString() {
		return String.valueOf(getIdregioni());
	}
	
}
