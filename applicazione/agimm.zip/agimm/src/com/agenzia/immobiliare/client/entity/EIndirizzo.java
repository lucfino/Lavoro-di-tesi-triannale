/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class EIndirizzo implements Serializable {
	public EIndirizzo() {
	}
	
	public EIndirizzo(String reg, String pro, String cit, String vi, int i) {
		this.regione=reg;
		this.provincia=pro;
		this.citta=cit;
		this.civico=i;
		this.via=vi;
	}

	private int ID;
	
	private String regione;
	
	private String provincia;
	
	private String citta;
	
	private String via;
	
	private int civico;
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setRegione(String value) {
		this.regione = value;
	}
	
	public String getRegione() {
		return regione;
	}
	
	public void setProvincia(String value) {
		this.provincia = value;
	}
	
	public String getProvincia() {
		return provincia;
	}
	
	public void setCitta(String value) {
		this.citta = value;
	}
	
	public String getCitta() {
		return citta;
	}
	
	public void setVia(String value) {
		this.via = value;
	}
	
	public String getVia() {
		return via;
	}
	
	public void setCivico(int value) {
		this.civico = value;
	}
	
	public int getCivico() {
		return civico;
	}
	
	public String toString() {
		String a =  "via "+via+", "+citta+", "+provincia+", "+regione;
		return a;
	}
	
}
