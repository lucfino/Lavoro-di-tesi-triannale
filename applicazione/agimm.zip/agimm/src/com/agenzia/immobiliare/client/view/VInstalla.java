package com.agenzia.immobiliare.client.view;

import com.agenzia.immobiliare.client.controller.CInstalla;
import com.agenzia.immobiliare.shared.Controlli;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.BlurEvent;
import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class VInstalla {
	
	private VInstalla(){}
	
	private static VInstalla installa;
	
	public static VInstalla getVInstalla(){
		if (installa == null){
			installa = new VInstalla();
		}
		return installa;
	}

	public AbsolutePanel getHello(){
		AbsolutePanel panel = new AbsolutePanel();
		panel.setStyleName("bordo");
		AbsolutePanel absolutePanel = new AbsolutePanel();
		absolutePanel.setStyleName("panel-hello");
		panel.add(absolutePanel, 479, 198);
		absolutePanel.setSize("442px", "320px");
		Button installazione = new Button("INIZIA L'INSTALLAZIONE");
		installazione.setStyleName("hello-button");
		absolutePanel.add(installazione, 125, 238);
		installazione.setSize("221px", "72px");
		Label benvenuto = new Label("BENVENUTO NELLA FASE DI INSTALLAZIONE DELL'APPLICAZIONE. VERRAI GUIDATO IN 3 FASI CHE TI PERMETTERANNO DI INSTALLARE L'APLLICAZIONE E DI CUSTUMIZZARLA");
		benvenuto.setStyleName("hello");
		absolutePanel.add(benvenuto, 125, 10);
		benvenuto.setSize("221px", "222px");
		installazione.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installa = CInstalla.getCInstalla();
				installa.passo1();
			}
		});
		return panel;
	}

	public AbsolutePanel getPasso1(){
		final Controlli c = Controlli.getControlli();
		AbsolutePanel panel = new AbsolutePanel();
		panel.setSize("1448px", "801px");
		panel.setStyleName("box-installa");
		Image passo1 = new Image("freccia.gif");
		panel.add(passo1, 333, 30);
		passo1.setSize("134px", "100px");
		Image passo2 = new Image("freccia.gif");
		panel.add(passo2, 549, 28);
		passo2.setSize("134px", "100px");
		Image passo3 = new Image("freccia.gif");
		panel.add(passo3, 768, 28);
		passo3.setSize("134px", "100px");
		Image passo4 = new Image("freccia.gif");
		panel.add(passo4, 969, 28);
		passo4.setSize("134px", "100px");
		AbsolutePanel database = new AbsolutePanel();
		database.setStyleName("box-installa");
		panel.add(database, 335, 136);
		database.setSize("771px", "269px");
		Label infoDatabase = new Label("Informazioni Database");
		infoDatabase.setStyleName("label-installa");
		database.add(infoDatabase, 12, 14);
		infoDatabase.setSize("753px", "16px");
		Label lnomeDatabase = new Label("nome database :");
		database.add(lnomeDatabase, 22, 57);
		final TextBox tnomeDatabase = new TextBox();
		database.add(tnomeDatabase, 149, 47);
		tnomeDatabase.setSize("149px", "16px");
		tnomeDatabase.setFocus(true);
		Label lposizioneDatabase = new Label("posizione database :");
		database.add(lposizioneDatabase, 409, 57);
		final TextBox tposizioneDatabase = new TextBox();
		database.add(tposizioneDatabase, 578, 47);
		tposizioneDatabase.setSize("149px", "16px");
		Label lpasswordDatabase = new Label("password  :");
		database.add(lpasswordDatabase, 24, 133);
		final PasswordTextBox tpasswordDatabase = new PasswordTextBox();
		database.add(tpasswordDatabase, 151, 123);
		tpasswordDatabase.setSize("149px", "16px");
		Label lconfermaDatabase = new Label("conferma password :");
		database.add(lconfermaDatabase, 411, 135);
		final PasswordTextBox tconfermaDatabase = new PasswordTextBox();
		database.add(tconfermaDatabase, 580, 123);
		tconfermaDatabase.setSize("149px", "16px");
		Label lusernameDatabase = new Label("username :");
		database.add(lusernameDatabase, 24, 205);
		final TextBox tusernameDatabase = new TextBox();
		database.add(tusernameDatabase, 151, 195);
		tusernameDatabase.setSize("149px", "16px");
		Label lportaDatabase = new Label("numero porta :");
		database.add(lportaDatabase, 411, 207);
		final TextBox tportaDatabase = new TextBox();
		database.add(tportaDatabase, 580, 195);
		tportaDatabase.setSize("149px", "16px");
		final Label errnomedb = new Label("");
		errnomedb.setStyleName("err");
		database.add(errnomedb, 151, 83);
		errnomedb.setSize("161px", "16px");
		final Label errposdb = new Label("");
		errposdb.setStyleName("err");
		database.add(errposdb, 580, 83);
		errposdb.setSize("161px", "16px");
		final Label errpassdb = new Label("");
		errpassdb.setStyleName("err");
		database.add(errpassdb, 149, 151);
		errpassdb.setSize("161px", "16px");
		final Label errcpssdb = new Label("");
		errcpssdb.setStyleName("err");
		database.add(errcpssdb, 582, 153);
		errcpssdb.setSize("157px", "16px");
		final Label erruserdb = new Label("");
		erruserdb.setStyleName("err");
		database.add(erruserdb, 151, 230);
		erruserdb.setSize("163px", "16px");
		final Label errportadb = new Label("");
		errportadb.setStyleName("err");
		database.add(errportadb, 578, 232);
		errportadb.setSize("161px", "16px");
		tnomeDatabase.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaNomeDatabase(tnomeDatabase.getText());
				if (!err.equals("")){
					errnomedb.setText(err);
				}else{
					errnomedb.setText("");
				}
			}

			
		});
		tposizioneDatabase.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaPosizioneDatabase(tposizioneDatabase.getText());
				if (!err.equals("")){
					errposdb.setText(err);
				}else{
					errposdb.setText("");
				}
				
			}
			
		});
		tconfermaDatabase.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaPasswordDatabase(tpasswordDatabase.getText(),tconfermaDatabase.getText());
				if (!err.equals("")){
					errcpssdb.setText(err);
				}else{
					errcpssdb.setText("");
				}
				
			}
			
		});
		tusernameDatabase.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaUsername(tusernameDatabase.getText());
				if (!err.equals("")){
					erruserdb.setText(err);
				}else{
					erruserdb.setText("");
				}
				
			}
			
		});
		tportaDatabase.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaPorta(tportaDatabase.getText());
				if (!err.equals("")){
					errportadb.setText(err);
				}else{
					errportadb.setText("");
				}
				
			}
			
		});
		AbsolutePanel mail = new AbsolutePanel();
		mail.setStyleName("dnd");
		panel.add(mail, 335, 418);
		mail.setSize("771px", "269px");
		Label servizioMail = new Label("Servizio Mail");
		servizioMail.setStyleName("label-installa");
		mail.add(servizioMail, 12, 14);
		servizioMail.setSize("753px", "16px");
		Label lserverMail = new Label("server mail :");
		mail.add(lserverMail, 24, 49);
		final TextBox tservizioMail = new TextBox();
		mail.add(tservizioMail, 151, 39);
		tservizioMail.setSize("149px", "16px");
		Label lporta = new Label("numero di porta :");
		mail.add(lporta, 410, 51);
		final TextBox tporta = new TextBox();
		mail.add(tporta, 580, 39);
		tporta.setSize("149px", "16px");
		Label lpasswordMail = new Label("password :");
		mail.add(lpasswordMail, 26, 194);
		final PasswordTextBox tpasswordMail = new PasswordTextBox();
		mail.add(tpasswordMail, 153, 184);
		tpasswordMail.setSize("149px", "16px");
		tpasswordMail.setEnabled(false);
		Label lconfermaMail = new Label("conferma password :");
		mail.add(lconfermaMail, 412, 192);
		final PasswordTextBox tconfermaMail = new PasswordTextBox();
		mail.add(tconfermaMail, 582, 185);
		tconfermaMail.setSize("149px", "16px");
		tconfermaMail.setEnabled(false);
		final CheckBox autenticazione = new CheckBox("autenticazione");
		mail.add(autenticazione, 151, 116);
		Label lusernameMail = new Label("username :");
		mail.add(lusernameMail, 412, 118);
		final TextBox tusernameMail = new TextBox();
		mail.add(tusernameMail, 582, 110);
		tusernameMail.setSize("149px", "16px");
		tusernameMail.setEnabled(false);
		final Label errserver = new Label("");
		errserver.setStyleName("err");
		mail.add(errserver, 155, 77);
		errserver.setSize("159px", "16px");
		final Label errportamail = new Label("");
		errportamail.setStyleName("err");
		mail.add(errportamail, 582, 75);
		errportamail.setSize("161px", "16px");
		final Label errcpassmail = new Label("");
		errcpassmail.setStyleName("err");
		mail.add(errcpassmail, 157, 224);
		errcpassmail.setSize("157px", "16px");
		final Label errusermail = new Label("");
		errusermail.setStyleName("err");
		mail.add(errusermail, 582, 145);
		errusermail.setSize("161px", "16px");
		tservizioMail.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaEmail(tservizioMail.getText());
				if (!err.equals("")){
					errserver.setText(err);
				}else{
					errserver.setText("");
				}
				
			}
			
		});
		tporta.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaPorta(tporta.getText());
				if (!err.equals("")){
					errportamail.setText(err);
				}else{
					errportamail.setText("");
				}
				
			}
			
		});
		tconfermaMail.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaPasswordMail(tpasswordMail.getText(),tconfermaMail.getText());
				if (!err.equals("")){
					errcpassmail.setText(err);
				}else{
					errcpassmail.setText("");
				}
				
			}
			
		});
		tusernameMail.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaUsernameMail(tusernameMail.getText());
				if (!err.equals("")){
					errusermail.setText(err);
				}else{
					errusermail.setText("");
				}
				
			}
			
		});
		Button cancella = new Button("CANCELLA");
		panel.add(cancella, 335, 699);
		cancella.setSize("120px", "30px");
		Button indietro = new Button("CANCELLA");
		indietro.setText("<- INDIETRO");
		panel.add(indietro, 866, 701);
		indietro.setSize("120px", "30px");
		Button avanti = new Button("CANCELLA");
		avanti.setText("AVANTI ->");
		panel.add(avanti, 990, 701);
		avanti.setSize("120px", "30px");
		final Label errpasso1 = new Label("");
		errpasso1.setStyleName("err");
		panel.add(errpasso1, 460, 697);
		errpasso1.setSize("385px", "30px");
		autenticazione.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				if(autenticazione.getValue()){
					tusernameMail.setEnabled(true);
					tpasswordMail.setEnabled(true);
					tconfermaMail.setEnabled(true);
				}else{
					tusernameMail.setEnabled(false);
					tpasswordMail.setEnabled(false);
					tconfermaMail.setEnabled(false);
				}
				
			}
			
		});
		cancella.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				tnomeDatabase.setText("");
				tposizioneDatabase.setText("");
				tpasswordDatabase.setText("");
				tconfermaDatabase.setText("");
				tservizioMail.setText("");
				tporta.setText("");
				tpasswordMail.setText("");
				tconfermaMail.setText("");
				autenticazione.setValue(false);
				tusernameMail.setText("");
			}
		});
		avanti.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
					CInstalla installa = CInstalla.getCInstalla();
					final String[] config = new String[22];
					config[0] = tnomeDatabase.getText();
					config[1] = tposizioneDatabase.getText();
					config[2] = tpasswordDatabase.getText();
					config[3] = tconfermaDatabase.getText();
					config[4] = tservizioMail.getText();
					config[5] = tporta.getText();
					config[6] = "";
					config[7] = "";
					config[8] = "";	
					autenticazione.addClickHandler(new ClickHandler(){

						@Override
						public void onClick(ClickEvent event) {
							if (autenticazione.getValue()){
								config[6] = tpasswordMail.getText();
								config[7] = tconfermaMail.getText();
								config[8] = tusernameMail.getText();	
							}else{
								config[6] = "";
								config[7] = "";
								config[8] = "";	
							}
							
						}
						
					});
					config[9] = tusernameDatabase.getText();
					config[10] = tportaDatabase.getText();
					String err1 = c.controllaNomeDatabase(config[0]);
					String err2 = c.controllaPosizioneDatabase(config[1]);
					String err3 = c.controllaPasswordDatabase(config[2], config[3]);
					String err4 = c.controllaEmail(config[4]);
					String err5 = c.controllaPorta(config[5]);
					String err6 = c.controllaPasswordMail(config[6], config[7]);
					String err7 = c.controllaUsernameMail(config[8]);
					String err8 = c.controllaUsername(config[9]);
					String err9 = c.controllaPorta(config[10]);
					if (err1.equals("") && err2.equals("") && err3.equals("") && err4.equals("") && err5.equals("") && err6.equals("") && err7.equals("") && err8.equals("") && err9.equals("") ){
						installa.passo2(config);
					}else{
						errpasso1.setText("ATTENZIONE!! CI DEVE ESSERE QUALCHE ERRORE! IMPOSSIBILE PROCEDERE");
					}
					
			}

		});
		indietro.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installa = CInstalla.getCInstalla();
				installa.hello();
			}
		});
		return panel;
	}

	public AbsolutePanel getPasso2(final String[] config){
		final Controlli c = Controlli.getControlli();
		AbsolutePanel panel = new AbsolutePanel();
		final FormPanel form = new FormPanel();
		form.setAction( GWT.getModuleBaseURL() );
		form.setEncoding(FormPanel.ENCODING_MULTIPART);
	    form.setMethod(FormPanel.METHOD_POST);
		form.add(panel);
		
		panel.setSize("1448px", "801px");
		panel.setStyleName("box-installa");
		Image passo1 = new Image("freccia.gif");
		panel.add(passo1, 333, 30);
		passo1.setSize("134px", "100px");
		Image passo2 = new Image("freccia.gif");
		panel.add(passo2, 549, 28);
		passo2.setSize("134px", "100px");
		Image passo3 = new Image("freccia.gif");
		panel.add(passo3, 768, 28);
		passo3.setSize("134px", "100px");
		Image passo4 = new Image("freccia.gif");
		panel.add(passo4, 969, 28);
		passo4.setSize("134px", "100px");
		AbsolutePanel admin = new AbsolutePanel();
		admin.setStyleName("box-installa");
		panel.add(admin, 335, 142);
		admin.setSize("783px", "544px");
		Label infoAdmin = new Label("Informazioni Agenzia");
		infoAdmin.setStyleName("label-installa");
		admin.add(infoAdmin, 12, 14);
		infoAdmin.setSize("753px", "16px");
		Label lnomeAdmin = new Label("username :");
		admin.add(lnomeAdmin, 22, 57);
		final TextBox tnomeAdmin = new TextBox();
		admin.add(tnomeAdmin, 149, 47);
		tnomeAdmin.setSize("149px", "16px");
		Label lpasswordAdmin = new Label("password :");
		admin.add(lpasswordAdmin, 460, 57);
		final PasswordTextBox tpasswordAdmin = new PasswordTextBox();
		admin.add(tpasswordAdmin, 584, 47);
		tpasswordAdmin.setSize("149px", "16px");
		Label lconfermaAdmin = new Label("conferma :");
		admin.add(lconfermaAdmin, 24, 145);
		final PasswordTextBox tconfermaAdmin = new PasswordTextBox();
		admin.add(tconfermaAdmin, 151, 135);
		tconfermaAdmin.setSize("149px", "16px");
		final Label erruser = new Label("");
		erruser.setStyleName("err");
		admin.add(erruser, 151, 83);
		erruser.setSize("161px", "16px");
		final Label errcpass = new Label("");
		errcpass.setStyleName("err");
		admin.add(errcpass, 149, 176);
		errcpass.setSize("161px", "16px");
		Label lregioneSociale = new Label("regione sociale :");
		admin.add(lregioneSociale, 461, 147);
		final TextBox tregioneSociale = new TextBox();
		admin.add(tregioneSociale, 586, 135);
		final Label errsociale = new Label("");
		errsociale.setStyleName("err");
		admin.add(errsociale, 586, 178);
		errsociale.setSize("157px", "16px");
		Label ltelefono = new Label("telefono :");
		admin.add(ltelefono, 24, 236);
		final TextBox ttelefono = new TextBox();
		admin.add(ttelefono, 151, 226);
		ttelefono.setSize("149px", "16px");
		Label lfax = new Label("fax :");
		admin.add(lfax, 462, 236);
		lfax.setSize("25px", "16px");
		final Label errfax = new Label("");
		errfax.setStyleName("err");
		admin.add(errfax, 586, 262);
		errfax.setSize("159px", "16px");
		final TextBox tfax = new TextBox();
		admin.add(tfax, 586, 226);
		
		final FileUpload logo = new FileUpload();
		admin.add(logo, 153, 318);
		Label lblLogo = new Label("logo:");
		admin.add(lblLogo, 24, 326);
		lblLogo.setSize("25px", "16px");
		
		Label lblIndirizzo = new Label("indirizzo:");
		admin.add(lblIndirizzo, 462, 326);
		final TextBox tindirizzo = new TextBox();
		admin.add(tindirizzo, 586, 314);
		
		final TextArea descrizione = new TextArea();
		admin.add(descrizione, 28, 413);
		descrizione.setSize("343px", "84px");
		
		final Label errtel = new Label("");
		errtel.setStyleName("err");
		admin.add(errtel, 151, 264);
		errtel.setSize("159px", "16px");
		
		final Label errdesc = new Label("");
		errdesc.setStyleName("err");
		admin.add(errdesc, 24, 515);
		errdesc.setSize("351px", "16px");
		
		Label lblDescriozine = new Label("descrizione:");
		admin.add(lblDescriozine, 24, 383);
		
		final Label errind = new Label("");
		errind.setStyleName("err");
		admin.add(errind, 590, 352);
		errind.setSize("155px", "16px");
		
		Label errlogo = new Label("");
		errlogo.setStyleName("err");
		admin.add(errlogo, 153, 356);
		errlogo.setSize("161px", "16px");
		
		Label lmail = new Label("mail:");
		admin.add(lmail, 463, 422);
		
		final TextBox tmail = new TextBox();
		tmail.setText("");
		admin.add(tmail, 586, 412);
		
		final Label errmail = new Label("");
		errmail.setStyleName("err");
		admin.add(errmail, 588, 450);
		errmail.setSize("157px", "16px");
		
		tfax.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaFax(tfax.getText());
				if (!err.equals("")){
					errfax.setText(err);
				}else{
					errfax.setText("");
				}
				
			}
			
		});
		ttelefono.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaTelefono(ttelefono.getText());
				if (!err.equals("")){
					errtel.setText(err);
				}else{
					errtel.setText("");
				}
				
			}
			
		});
		tregioneSociale.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaNomeAgenzia(tregioneSociale.getText());
				if (!err.equals("")){
					errsociale.setText(err);
				}else{
					errsociale.setText("");
				}
				
			}
			
		});
		tnomeAdmin.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaUsername(tnomeAdmin.getText());
				if (!err.equals("")){
					erruser.setText(err);
				}else{
					erruser.setText("");
				}
				
			}
			
		});
		tconfermaAdmin.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaPassword(tpasswordAdmin.getText(),tconfermaAdmin.getText());
				if (!err.equals("")){
					errcpass.setText(err);
				}else{
					errcpass.setText("");
				}
				
			}
			
		});
		descrizione.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaDescrizione(descrizione.getText());
				if (!err.equals("")){
					errdesc.setText(err);
				}else{
					errdesc.setText("");
				}
				
			}
			
		});
		tmail.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaEmail(tmail.getText());
				if (!err.equals("")){
					errmail.setText(err);
				}else{
					errmail.setText("");
				}
				
			}
			
		});
		tindirizzo.addBlurHandler(new BlurHandler(){

			@Override
			public void onBlur(BlurEvent event) {
				String err = c.controllaIndirizzo(tindirizzo.getText());
				if (!err.equals("")){
					errind.setText(err);
				}else{
					errind.setText("");
				}
				
			}
			
		});

		//controllo logo
		final Label errpasso2 = new Label("");
		errpasso2.setStyleName("err");
		panel.add(errpasso2, 467, 705);
		errpasso2.setSize("397px", "28px");
		Button cancella = new Button("CANCELLA");
		panel.add(cancella, 335, 705);
		cancella.setSize("120px", "30px");
		Button indietro = new Button("CANCELLA");
		indietro.setText("<- INDIETRO");
		panel.add(indietro, 880, 705);
		indietro.setSize("120px", "30px");
		Button avanti = new Button("CANCELLA" , new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				CInstalla installa = CInstalla.getCInstalla();
				config[11] = tnomeAdmin.getText();
				config[12] = tregioneSociale.getText();
				config[13] = tpasswordAdmin.getText();
				config[14] = tconfermaAdmin.getText();
				config[15] = tindirizzo.getText();
				config[16] = tfax.getText();
				config[17] = ttelefono.getText();
				config[18] = descrizione.getText();
				config[19] = tmail.getText();
				config[20] = logo.getFilename();
				String err1 = c.controllaUsername(tnomeAdmin.getText());
				String err2 = c.controllaNomeAgenzia(tregioneSociale.getText());
				String err3 = c.controllaPassword(tpasswordAdmin.getText(),tconfermaAdmin.getText());
				String err4 = c.controllaIndirizzo(tindirizzo.getText());
				String err5 = c.controllaFax(tfax.getText());
				String err6 = c.controllaTelefono(ttelefono.getText());
				String err7 = c.controllaDescrizione(descrizione.getText());
				String err8 = c.controllaEmail(tmail.getText());
				if (err1.equals("") && err2.equals("") && err3.equals("") && err4.equals("") && err5.equals("") && err6.equals("") && err7.equals("") && err8.equals("")){
					installa.passo4(config);
				}else{
					errpasso2.setText("ATTENZIONE!! CI DEVE ESSERE QUALCHE ERRORE! IMPOSSIBILE PROCEDERE");
				}
			}
		});
		avanti.setText("AVANTI ->");
		panel.add(avanti, 1004, 705);
		avanti.setSize("120px", "30px");
		cancella.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				tnomeAdmin.setText("");
				tregioneSociale.setText("");
				tpasswordAdmin.setText("");
				tconfermaAdmin.setText("");
				tindirizzo.setText("");
				tfax.setText("");
				ttelefono.setText("");
				descrizione.setText("");
			}
		});
		indietro.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installa = CInstalla.getCInstalla();
				installa.passo1();
			}
		});
		
		return panel;
	}

	public AbsolutePanel getPasso3(final String[] config){
		AbsolutePanel panel = new AbsolutePanel();
		Button cancella = new Button("CANCELLA");
		panel.add(cancella, 289, 575);
		cancella.setSize("120px", "30px");
		Button avanti = new Button("CANCELLA");
		avanti.setText("AVANTI ->");
		panel.add(avanti, 731, 575);
		avanti.setSize("120px", "30px");
		Button indietro = new Button("CANCELLA");
		indietro.setText("<- INDIETRO");
		panel.add(indietro, 605, 575);
		indietro.setSize("120px", "30px");
		indietro.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installa = CInstalla.getCInstalla();
				installa.passo2(config);
			}
		});
		avanti.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installa = CInstalla.getCInstalla();
				installa.passo4(config);
			}
		});
		cancella.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
			
			}
		});
		return panel;
	}

	public AbsolutePanel getPasso4(final String[] config){
		AbsolutePanel panel = new AbsolutePanel();
		panel.setSize("1444", "800");
		Image passo1 = new Image("freccia.gif");
		panel.add(passo1, 333, 30);
		passo1.setSize("134px", "100px");
		Image passo2 = new Image("freccia.gif");
		panel.add(passo2, 549, 28);
		passo2.setSize("134px", "100px");
		Image passo3 = new Image("freccia.gif");
		panel.add(passo3, 768, 28);
		passo3.setSize("134px", "100px");
		Image passo4 = new Image("freccia.gif");
		panel.add(passo4, 969, 28);
		passo4.setSize("134px", "100px");
		AbsolutePanel style = new AbsolutePanel();
		style.setStyleName("box-installa");
		panel.add(style, 335, 138);
		style.setSize("779px", "548px");
		final ListBox stile = new ListBox();
		stile.setStyleName("lista-installa");
		style.add(stile, 10, 141);
		stile.setSize("176px", "389px");
		stile.setVisibleItemCount(10);
		stile.addItem("standard","standard");
		stile.addItem("stile1","stile1");
		stile.addItem("stile2","stile2");
		stile.addItem("stile3","stile3");
		stile.addItem("stile4","stile4");
		stile.addItem("stile5","stile5");
		stile.addItem("stile6","stile6");
		stile.addItem("stile7","stile7");
		stile.addItem("stile8","stile8");
		stile.addItem("stile9","stile9");
		stile.setItemSelected(0, true);
		Label lstile = new Label("SCEGLI UNO STILE");
		lstile.setStyleName("label-installa");
		style.add(lstile, 12, 107);
		lstile.setSize("174px", "30px");
		Label lblNewLabel_2 = new Label("Custumizzazione");
		lblNewLabel_2.setStyleName("label-installa");
		style.add(lblNewLabel_2, 14, 14);
		lblNewLabel_2.setSize("751px", "16px");
		Label lblNewLabel_3 = new Label("custumizza la tua applicazione scelgiendo uno dei temi proposti nella lista sottostante. il tema influir\u00E0 su colore dello sfondo, bordi, grandezza e colore del testo ecc.");
		style.add(lblNewLabel_3, 12, 42);
		lblNewLabel_3.setSize("755px", "60px");
		final AbsolutePanel prova = new AbsolutePanel();
		style.add(prova, 204, 109);
		prova.setSize("551px", "399px");
		final AbsolutePanel absolutePanel = new AbsolutePanel();
		prova.add(absolutePanel, 71, 94);
		absolutePanel.setSize("388px", "146px");
		final Label lblNewLabel = new Label("TESTO di PROVA");
		absolutePanel.add(lblNewLabel, 0, 0);
		lblNewLabel.setSize("398px", "26px");
		final Label lblNewLabel_1 = new Label("testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova testo di prova ");
		absolutePanel.add(lblNewLabel_1, 4, 40);
		lblNewLabel_1.setSize("388px", "110px");
		stile.addChangeHandler(new ChangeHandler(){

			@Override
			public void onChange(ChangeEvent event) {
				lblNewLabel_1.setStyleName(stile.getValue(stile.getSelectedIndex())+"-label");
				absolutePanel.setStyleName(stile.getValue(stile.getSelectedIndex())+"-panel");
				lblNewLabel.setStyleName(stile.getValue(stile.getSelectedIndex())+"-titolo");
				prova.setStyleName(stile.getValue(stile.getSelectedIndex()));
			}
			
		});
		Button cancella = new Button("CANCELLA");
		panel.add(cancella, 335, 703);
		cancella.setSize("120px", "30px");
		Button avanti = new Button("CANCELLA");
		avanti.setText("FINE");
		panel.add(avanti, 998, 703);
		avanti.setSize("120px", "30px");
		Button indietro = new Button("CANCELLA");
		indietro.setText("<- INDIETRO");
		panel.add(indietro, 870, 703);
		indietro.setSize("120px", "30px");
		cancella.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				stile.setItemSelected(0, true);
			}
		});
		
		indietro.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installazione = CInstalla.getCInstalla();
				installazione.passo3(config);
			}
		});
		
		avanti.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				CInstalla installazione = CInstalla.getCInstalla();
				config[21] = stile.getValue(stile.getSelectedIndex());
				installazione.installa(config);
			}
		});
		
		
		return panel;
	}

	public void stampa(AbsolutePanel panel){
		RootLayoutPanel.get().add(panel);
	}
}
