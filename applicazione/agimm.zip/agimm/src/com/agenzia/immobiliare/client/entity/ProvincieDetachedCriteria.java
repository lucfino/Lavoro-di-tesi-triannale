/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class ProvincieDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression idprovincia;
	public final StringExpression nomeprovincia;
	public final StringExpression siglaprovincia;
	public final IntegerExpression idregione;
	
	public ProvincieDetachedCriteria() {
		super(com.agenzia.immobiliare.client.entity.Provincie.class, com.agenzia.immobiliare.client.entity.ProvincieCriteria.class);
		idprovincia = new IntegerExpression("idprovincia", this.getDetachedCriteria());
		nomeprovincia = new StringExpression("nomeprovincia", this.getDetachedCriteria());
		siglaprovincia = new StringExpression("siglaprovincia", this.getDetachedCriteria());
		idregione = new IntegerExpression("idregione", this.getDetachedCriteria());
	}
	
	public ProvincieDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, com.agenzia.immobiliare.client.entity.ProvincieCriteria.class);
		idprovincia = new IntegerExpression("idprovincia", this.getDetachedCriteria());
		nomeprovincia = new StringExpression("nomeprovincia", this.getDetachedCriteria());
		siglaprovincia = new StringExpression("siglaprovincia", this.getDetachedCriteria());
		idregione = new IntegerExpression("idregione", this.getDetachedCriteria());
	}
	
	public Provincie uniqueProvincie(PersistentSession session) {
		return (Provincie) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Provincie[] listProvincie(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Provincie[]) list.toArray(new Provincie[list.size()]);
	}
}

