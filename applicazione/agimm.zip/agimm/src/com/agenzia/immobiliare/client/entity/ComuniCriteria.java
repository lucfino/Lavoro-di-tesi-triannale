/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class ComuniCriteria extends AbstractORMCriteria {
	public final IntegerExpression idcomune;
	public final StringExpression nomecomune;
	public final IntegerExpression idprovincia;
	public final IntegerExpression idregione;
	
	public ComuniCriteria(Criteria criteria) {
		super(criteria);
		idcomune = new IntegerExpression("idcomune", this);
		nomecomune = new StringExpression("nomecomune", this);
		idprovincia = new IntegerExpression("idprovincia", this);
		idregione = new IntegerExpression("idregione", this);
	}
	
	public ComuniCriteria(PersistentSession session) {
		this(session.createCriteria(Comuni.class));
	}
	
	public ComuniCriteria() throws PersistentException {
		this(com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession());
	}
	
	public Comuni uniqueComuni() {
		return (Comuni) super.uniqueResult();
	}
	
	public Comuni[] listComuni() {
		java.util.List list = super.list();
		return (Comuni[]) list.toArray(new Comuni[list.size()]);
	}
}

