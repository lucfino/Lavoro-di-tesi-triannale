package com.agenzia.immobiliare.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("installa")
public interface Installa extends RemoteService{

	String installa(String[] config);
	
}
