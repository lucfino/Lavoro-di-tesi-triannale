/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class Garage extends com.agenzia.immobiliare.client.entity.ECommerciale implements Serializable {
	public Garage() {
	}
	
	private int posti_auto;
	
	public Garage(EIndirizzo ind, int sup, int pre, int pos){
		super(ind, sup, pre);
		this.posti_auto=pos;
	}
	
	public void setPosti_auto(int value) {
		this.posti_auto = value;
	}
	
	public int getPosti_auto() {
		return posti_auto;
	}
	
	public String toString() {
		return super.toString();
	}
	
}
