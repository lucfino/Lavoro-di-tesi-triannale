package com.agenzia.immobiliare.client;

import java.util.LinkedList;

import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.view.IVMapsAdapter;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("utility")
public interface Utility extends RemoteService{
	
	String[] esiste(String path);
	
	boolean autentica(String user, String pass);

	String controlla();
	
	boolean loggato();
	
	void logout();
	
	void salva(int id);
	
	LinkedList<EAnnuncio> carica();
	
	IVMapsAdapter carica(String name);
	
}
