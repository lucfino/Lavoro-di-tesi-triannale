/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.client.entity;

import java.io.Serializable;
public class Terreni extends com.agenzia.immobiliare.client.entity.ECommerciale implements Serializable {
	public Terreni() {
	}
	
	private String proprieta;
	
	private String colture;
	
	public Terreni(EIndirizzo ind, int sup, int pre, String col, String pro){
		super(ind, sup, pre);
		this.colture=col;
		this.proprieta=pro;
	}
	
	public void setProprieta(String value) {
		this.proprieta = value;
	}
	
	public String getProprieta() {
		return proprieta;
	}
	
	public void setColture(String value) {
		this.colture = value;
	}
	
	public String getColture() {
		return colture;
	}
	
	public String toString() {
		return super.toString();
	}
	
}
