package com.agenzia.immobiliare.shared;

public class Controlli {
	
	private Controlli(){}
	
	private static Controlli controlli;
	
	public static Controlli getControlli(){
		if (controlli == null){
			controlli = new Controlli();
		}
		return controlli;
	}
	
	
	public String controllaTestoSemplice(String nome){
		String err = "";
		if (nome== null){
			err = "Campo obbligatorio";
		}else{
			if (!nome.matches("[a-zA-Z]{1,}")){
				err = "Errore nell'inserimento del campo";
			}
		}
		return err;
	}
	
	
	public String controllaNumeri(String i){
		String err = "";
		if (i== null){
			err = "Campo obbligatorio";
		}else{
			String regex = "[0-9]{1,}";
			if (!i.matches(regex)){
				err = "Errore nell'inserimento del campo";
			}
		}
		return err;
	}
	
	public String controllaNomeDatabase(String nome){
		String err = "";
		if (nome== null){
			err = "Campo obbligatorio";
		}else{
			if (!nome.matches("[a-zA-Z0-9]{1,10}")){
				err = "Errore in nome del databse";
			}
		}
		return err;
	}
	
	public String controllaPosizioneDatabase(String nome){
		String err = "";
		if (nome== null){
			err = "Campo obbligatorio";
		}else{
			if (!nome.matches("[a-zA-Z0-9]{1,20}")){
				err = "Errore in posizione del database";
			}
		}
		return err;
	}
	
	public String controllaPasswordDatabase(String pass, String cpass){
		String err = "";
		String regex = "[0-9a-zA-Z]{0,15}";
	    if(!pass.matches(regex)){
	        err = "Errore nella password";
	    }else{
	        if(!pass.equals(cpass)){
	        	err = "I campi password e conferma password non coincidono";
	        }
	    }
		return err;
	}
	
	public String controllaPassword(String pass, String cpass){
		String err = "";
		if (pass.equals("")){
			if(cpass.equals("")){
				err = "Devi confermare la password";
			}else{
				String regex = "[0-9a-zA-Z]{5,15}";
		        if(!pass.matches(regex)){
		        	err = "Errore nella password";
		        }else{
		            if(!pass.equals(cpass)){
		            	err = "I campi password e conferma password non coincidono";
		             }
		        }
		    }
		}
		return err;
	}
	
	public String controllaPasswordMail(String pass, String cpass){
		String err = "";
		String regex = "[0-9a-zA-Z]{0,15}";
	    if(!pass.matches(regex)){
	    	err = "Errore nella password";
		}else{
		    if(!pass.equals(cpass)){
		    	err = "I campi password e conferma password non coincidono";
		    }
		}
		return err;
	}
	
	
	public String controllaPorta(String i){
		String err = "";
		if (i== null){
			err = "Campo obbligatorio";
		}else{
			String regex = "[0-9]{1,4}";
			if (!i.matches(regex)){
				err = "Errore nell'inserimento del campo";
			}
		}
		return err;
	}


	public String controllaEmail(String nome){
		String err = "";
		if (nome == null){
			err = "Campo obbligatorio";
		}else{
			String regex = "[a-zA-Z0-9]{3,15}";
			if (!nome.matches(regex)){
				err = "Errore nell'inserimento del campo";
			}
		}
		return err;
	}
	
	public String controllaUsername(String nome){
		String err = "";
		if (nome == null){
			err = "Campo obbligatorio";
		}else{
			String regex = "[a-zA-Z0-9]{3,15}";
			if (!nome.matches(regex)){
				err = "Errore nello username";
			}
		}
		return err;
	}
	
	public String controllaUsernameMail(String nome){
		String err = "";
		String regex = "[a-zA-Z0-9]{0,15}";
		if (!nome.matches(regex)){
			err = "Errore nello username";
		}
		return err;
	}
	
	public String controllaNomeAgenzia(String nome){
		String err = "";
		if (nome.equals("")){
			err = "Campo obbligatorio";
		}else{
			if (!nome.matches("[a-zA-Z0-9]{1,25}")){
				err = "Errore nel nome dell'agenzia";
			}
		}
		return err;
	}
	
	public String controllaTelefono(String i){
		String err = "";
		if (i.equals("")){
			err = "Campo obbligatorio";
		}else{
			String regex = "[0-9]{8,10}";
			if (!i.matches(regex)){
				err = "Errore nel numero di telefono";
			}
		}
		return err;
	}
	
	public String controllaFax(String nome){
		String err = "";
		if (nome.equals("")){
			err = "Campo obbligatorio";
		}else{
			String regex = "[0-9]{1,7}";
			if (!nome.matches(regex)){
				err = "Errore nell'inserimento del campo";
			}
		}
		return err;
	}
	
	public String controllaDescrizione(String nome){
		String err = "";
		if (nome.equals("")){
			err = "Campo obbligatorio";
		}else{
			if (!nome.matches("[A-Za-z]{0,255}")){
				err = "Errore nell'inserimento del campo";
			}
		}
		return err;
	}
	
	public String controllaIndirizzo(String nome){
		String err = "";
		if (nome.equals("")){
			err = "Campo obbligatorio";
		}else{
			if (!nome.matches("[a-zA-Z]{1,}")){
				err = "Errore nell' indirizzo";
			}
		}
		return err;
	}
	
	public boolean colture (String col){
		boolean err = false;
		if (col.equals("rape") || col.equals("bietola") || col.equals("carote") || col.equals("spinaci")){
			err = true;
		}
		return err;
	}
	
	public boolean posti (String col){
		boolean err = false;
		if (col.equals("1") || col.equals("2") || col.equals("3") || col.equals("4")){
			err = true;
		}
		return err;
	}
	
	public boolean proprieta (String col){
		boolean err = false;
		if (col.equals("proprieta1") || col.equals("proprieta2") || col.equals("proprieta3") || col.equals("proprieta4")){
			err = true;
		}
		return err;
	}
	
	public String stile (String col){
		String err = "";
		if (col.equals("stile1") || col.equals("stile2") || col.equals("stile3") || col.equals("stile4") || col.equals("stile5")|| col.equals("stile6")|| col.equals("stile7")|| col.equals("stile8")|| col.equals("stile9")){
			err = "errore";
		}
		return err;
	}
	
	
}
