package com.agenzia.immobiliare.shared;

public class Config {
	
	private String nomeDB;
	
	private String posizioneDB;
	
	private String passwprdDB;
	
	private String usernameDB;
	
	private int portaDB;
	
	private String serverMail;
	
	private String usernameMail;
	
	private String passwordMail;
	
	private int portaMail;
	
	private String nome;
	
	private String indirizzo;
	
	private int fax;
	
	private int telefono;
	
	private String email;
		
	private String logo;
	
	private String desc;
	
	private String stile;
	
	private String maps;
	
	private String map = "VMapsAdapter";
	
	private static Config config;
	
	private Config(){}
	
	public static Config getConfig(){
		if (config == null){
			config = new Config();
		}
		return config;
	}

	public String getNomeDB() {
		return nomeDB;
	}

	public void setNomeDB(String nomeDB) {
		this.nomeDB = nomeDB;
	}

	public String getPosizioneDB() {
		return posizioneDB;
	}

	public void setPosizioneDB(String posizioneDB) {
		this.posizioneDB = posizioneDB;
	}

	public String getPasswprdDB() {
		return passwprdDB;
	}

	public void setPasswprdDB(String passwprdDB) {
		this.passwprdDB = passwprdDB;
	}

	public String getUsernameDB() {
		return usernameDB;
	}

	public void setUsernameDB(String usernameDB) {
		this.usernameDB = usernameDB;
	}

	public int getPortaDB() {
		return portaDB;
	}

	public void setPortaDB(int portaDB) {
		this.portaDB = portaDB;
	}

	public String getServerMail() {
		return serverMail;
	}

	public void setServerMail(String serverMail) {
		this.serverMail = serverMail;
	}

	public String getUsernameMail() {
		return usernameMail;
	}

	public void setUsernameMail(String usernameMail) {
		this.usernameMail = usernameMail;
	}

	public String getPasswordMail() {
		return passwordMail;
	}

	public void setPasswordMail(String passwordMail) {
		this.passwordMail = passwordMail;
	}

	public int getPortaMail() {
		return portaMail;
	}

	public void setPortaMail(int portaMail) {
		this.portaMail = portaMail;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public int getFax() {
		return fax;
	}

	public void setFax(int fax) {
		this.fax = fax;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getStile() {
		return stile;
	}

	public void setStile(String stile) {
		this.stile = stile;
	}

	public void setMap(String map) {
		this.map = map;
	}

	public String getMap() {
		return map;
	}

	public void setMaps(String maps) {
		this.maps = maps;
	}

	public String getMaps() {
		return maps;
	}

	
}