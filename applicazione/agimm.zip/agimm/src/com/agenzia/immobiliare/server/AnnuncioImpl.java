package com.agenzia.immobiliare.server;

import java.util.LinkedList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;
import org.orm.PersistentException;
import org.orm.PersistentSession;

import com.agenzia.immobiliare.client.Annuncio;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.entity.EAnnuncioCriteria;
import com.agenzia.immobiliare.client.entity.Terreni;
import com.agenzia.immobiliare.server.orm.AgeziaPersistentManager;
import com.agenzia.immobiliare.server.orm.entity.EAnnuncioDAO;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

@SuppressWarnings("serial")
public class AnnuncioImpl extends RemoteServiceServlet implements Annuncio{

	@Override
	public EAnnuncio carica(int id) {
		EAnnuncio ann = new EAnnuncio();
		try {
			ann = EAnnuncioDAO.loadEAnnuncioByORMID(id);
		} catch (PersistentException e) {
			
			e.printStackTrace();
		}
		return ann;
	}
	
	@Override
	public boolean inserisciGarage(EAnnuncio ann) {
		try {
			PersistentSession s = AgeziaPersistentManager.instance().getSession();
			s.beginTransaction();
			s.save(ann.geteGarage().geteIndirizzo());
			s.save(ann.geteGarage());
			s.save(ann);
			s.getTransaction().commit();
		} catch (PersistentException e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean cancella(int id) {
		try {
			EAnnuncio eAnnuncio = carica(id);
			EAnnuncioDAO.delete(eAnnuncio);
		} catch (PersistentException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public LinkedList<EAnnuncio> cercaGarage(String reg, String pro,
			String cit, int prea, int preda, int supa, int supda, int pos) {
		LinkedList<EAnnuncio> ann = new LinkedList<EAnnuncio>();
		try {
			EAnnuncioCriteria c = new EAnnuncioCriteria();
			c.ID.between(1, 2);
			EAnnuncio[] an = EAnnuncioDAO.listEAnnuncioByCriteria(c);
			for (int i=0; i<an.length; i++){
				ann.add(an[i]);
			}
		} catch (PersistentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ann;
	}

	public LinkedList<EAnnuncio> cercaTerreni(String reg, String pro,
			String cit, int prea, int preda, int supa, int supda, String prop,
			String col) {
		LinkedList<EAnnuncio> ann = new LinkedList<EAnnuncio>();
		try{
			EAnnuncioCriteria c = new EAnnuncioCriteria();
			c.ID.between(3, 5);
			EAnnuncio[] an = EAnnuncioDAO.listEAnnuncioByCriteria(c);
			for (int i=0; i<an.length; i++){
				ann.add(an[i]);
			}
		}
		catch (PersistentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ann;
	}

	@Override
	public LinkedList<EAnnuncio> cerca() {
		LinkedList<EAnnuncio> ann = new LinkedList<EAnnuncio>();
		try{
			EAnnuncio[] an = EAnnuncioDAO.listEAnnuncioByQuery(null,null);
			for (int i=0; i<an.length; i++){
				ann.add(an[i]);
			}
		} catch (PersistentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ann;
	}

	@Override
	public boolean inserisciTerreni(EAnnuncio ann) {
		try {
			PersistentSession s = AgeziaPersistentManager.instance().getSession();
			s.beginTransaction();
			s.save(ann.geteTerreni().geteIndirizzo());
			s.save(ann.geteTerreni());
			s.save(ann);
			s.getTransaction().commit();
		} catch (PersistentException e) {
			
			e.printStackTrace();
		}
		return true;
	}



}
