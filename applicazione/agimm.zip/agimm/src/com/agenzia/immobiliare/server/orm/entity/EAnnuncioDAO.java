/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.server.orm.entity;

import org.orm.*;
import org.hibernate.Query;

import com.agenzia.immobiliare.client.entity.*;

import java.util.List;

public class EAnnuncioDAO {
	public static EAnnuncio loadEAnnuncioByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadEAnnuncioByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio getEAnnuncioByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getEAnnuncioByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadEAnnuncioByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio getEAnnuncioByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getEAnnuncioByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (EAnnuncio) session.load(com.agenzia.immobiliare.client.entity.EAnnuncio.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio getEAnnuncioByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (EAnnuncio) session.get(com.agenzia.immobiliare.client.entity.EAnnuncio.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (EAnnuncio) session.load(com.agenzia.immobiliare.client.entity.EAnnuncio.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio getEAnnuncioByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (EAnnuncio) session.get(com.agenzia.immobiliare.client.entity.EAnnuncio.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio[] listEAnnuncioByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listEAnnuncioByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio[] listEAnnuncioByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listEAnnuncioByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio[] listEAnnuncioByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.EAnnuncio as EAnnuncio");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			List list = query.list();
			return (EAnnuncio[]) list.toArray(new EAnnuncio[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio[] listEAnnuncioByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.EAnnuncio as EAnnuncio");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			List list = query.list();
			return (EAnnuncio[]) list.toArray(new EAnnuncio[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadEAnnuncioByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadEAnnuncioByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		EAnnuncio[] eAnnuncios = listEAnnuncioByQuery(session, condition, orderBy);
		if (eAnnuncios != null && eAnnuncios.length > 0)
			return eAnnuncios[0];
		else
			return null;
	}
	
	public static EAnnuncio loadEAnnuncioByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		EAnnuncio[] eAnnuncios = listEAnnuncioByQuery(session, condition, orderBy, lockMode);
		if (eAnnuncios != null && eAnnuncios.length > 0)
			return eAnnuncios[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateEAnnuncioByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateEAnnuncioByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateEAnnuncioByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateEAnnuncioByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateEAnnuncioByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.EAnnuncio as EAnnuncio");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateEAnnuncioByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.EAnnuncio as EAnnuncio");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio createEAnnuncio() {
		return new com.agenzia.immobiliare.client.entity.EAnnuncio();
	}
	
	public static boolean save(com.agenzia.immobiliare.client.entity.EAnnuncio eAnnuncio) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().saveObject(eAnnuncio);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(com.agenzia.immobiliare.client.entity.EAnnuncio eAnnuncio) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().deleteObject(eAnnuncio);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(com.agenzia.immobiliare.client.entity.EAnnuncio eAnnuncio) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().refresh(eAnnuncio);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(com.agenzia.immobiliare.client.entity.EAnnuncio eAnnuncio) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().evict(eAnnuncio);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static EAnnuncio loadEAnnuncioByCriteria(EAnnuncioCriteria eAnnuncioCriteria) {
		EAnnuncio[] eAnnuncios = listEAnnuncioByCriteria(eAnnuncioCriteria);
		if(eAnnuncios == null || eAnnuncios.length == 0) {
			return null;
		}
		return eAnnuncios[0];
	}
	
	public static EAnnuncio[] listEAnnuncioByCriteria(EAnnuncioCriteria eAnnuncioCriteria) {
		return eAnnuncioCriteria.listEAnnuncio();
	}
}
