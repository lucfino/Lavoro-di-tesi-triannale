package com.agenzia.immobiliare.server;

import java.util.LinkedList;

import org.orm.PersistentException;

import com.agenzia.immobiliare.client.Indirizzo;
import com.agenzia.immobiliare.client.entity.Comuni;
import com.agenzia.immobiliare.client.entity.ComuniCriteria;
import com.agenzia.immobiliare.client.entity.Provincie;
import com.agenzia.immobiliare.client.entity.ProvincieCriteria;
import com.agenzia.immobiliare.client.entity.Regioni;
import com.agenzia.immobiliare.server.orm.entity.ComuniDAO;
import com.agenzia.immobiliare.server.orm.entity.ProvincieDAO;
import com.agenzia.immobiliare.server.orm.entity.RegioniDAO;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class IndirizzoImpl extends RemoteServiceServlet implements Indirizzo {

	@Override
	public Regioni[] cercaRegioni() {
		Regioni[] r = new Regioni[20];
		try {
			r = RegioniDAO.listRegioniByQuery(null, null);
		} catch (PersistentException e) {
			
			e.printStackTrace();
		}
		return r;
	}

	@Override
	public LinkedList<Provincie> cercaProvincie(int id) {
		LinkedList<Provincie> p = new LinkedList<Provincie>();
		try {
			ProvincieCriteria c = new ProvincieCriteria();
			c.idregione.eq(id);
			Provincie[] pr = ProvincieDAO.listProvincieByQuery("siglaProvincia = "+id , null);
			for (int i=0; i<pr.length; i++){
				p.add(pr[i]);
			}
		} catch (PersistentException e) {
			
			e.printStackTrace();
		}
		return p;
	}

	@Override
	public LinkedList<String> cercaComuni(int id) {
		LinkedList<String> s = new LinkedList<String>();
		try {
			ComuniCriteria cr = new ComuniCriteria();
			cr.idprovincia.eq(id);
			Comuni[] c = ComuniDAO.listComuniByQuery("idprovincia = "+id , null);
			for (int i=0; i<c.length; i++){
				s.add(c[i].getNomecomune());
			}
		} catch (PersistentException e) {
			
			e.printStackTrace();
		}
		
		return s;
	}

	









	




	
	

	

}
