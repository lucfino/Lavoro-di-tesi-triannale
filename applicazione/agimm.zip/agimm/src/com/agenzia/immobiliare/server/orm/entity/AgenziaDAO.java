/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.server.orm.entity;

import org.orm.*;
import org.hibernate.Query;

import com.agenzia.immobiliare.client.entity.*;

import java.util.List;

public class AgenziaDAO {
	public static Agenzia loadAgenziaByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadAgenziaByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia getAgenziaByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getAgenziaByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadAgenziaByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia getAgenziaByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getAgenziaByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (Agenzia) session.load(com.agenzia.immobiliare.client.entity.Agenzia.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia getAgenziaByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (Agenzia) session.get(com.agenzia.immobiliare.client.entity.Agenzia.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Agenzia) session.load(com.agenzia.immobiliare.client.entity.Agenzia.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia getAgenziaByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Agenzia) session.get(com.agenzia.immobiliare.client.entity.Agenzia.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia[] listAgenziaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listAgenziaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia[] listAgenziaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listAgenziaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia[] listAgenziaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Agenzia as Agenzia");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			List list = query.list();
			return (Agenzia[]) list.toArray(new Agenzia[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia[] listAgenziaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Agenzia as Agenzia");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			List list = query.list();
			return (Agenzia[]) list.toArray(new Agenzia[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadAgenziaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadAgenziaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Agenzia[] agenzias = listAgenziaByQuery(session, condition, orderBy);
		if (agenzias != null && agenzias.length > 0)
			return agenzias[0];
		else
			return null;
	}
	
	public static Agenzia loadAgenziaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Agenzia[] agenzias = listAgenziaByQuery(session, condition, orderBy, lockMode);
		if (agenzias != null && agenzias.length > 0)
			return agenzias[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateAgenziaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateAgenziaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateAgenziaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateAgenziaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateAgenziaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Agenzia as Agenzia");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateAgenziaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Agenzia as Agenzia");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia createAgenzia() {
		return new com.agenzia.immobiliare.client.entity.Agenzia();
	}
	
	public static boolean save(com.agenzia.immobiliare.client.entity.Agenzia agenzia) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().saveObject(agenzia);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(com.agenzia.immobiliare.client.entity.Agenzia agenzia) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().deleteObject(agenzia);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(com.agenzia.immobiliare.client.entity.Agenzia agenzia) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().refresh(agenzia);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(com.agenzia.immobiliare.client.entity.Agenzia agenzia) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().evict(agenzia);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Agenzia loadAgenziaByCriteria(AgenziaCriteria agenziaCriteria) {
		Agenzia[] agenzias = listAgenziaByCriteria(agenziaCriteria);
		if(agenzias == null || agenzias.length == 0) {
			return null;
		}
		return agenzias[0];
	}
	
	public static Agenzia[] listAgenziaByCriteria(AgenziaCriteria agenziaCriteria) {
		return agenziaCriteria.listAgenzia();
	}
}
