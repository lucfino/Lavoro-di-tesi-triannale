package com.agenzia.immobiliare.server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.agenzia.immobiliare.client.Installa;
import com.agenzia.immobiliare.shared.Controlli;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

@SuppressWarnings("serial")
public class InstallaImpl extends RemoteServiceServlet implements Installa{

	@Override
	public String installa(String[] config) {
		String ok = "";
		Controlli c = Controlli.getControlli();
		String err1 = c.controllaNomeDatabase(config[0]);
		String err2 = c.controllaPosizioneDatabase(config[1]);
		String err3 = c.controllaPasswordDatabase(config[2], config[3]);
		String err4 = c.controllaEmail(config[4]);
		String err5 = c.controllaPorta(config[5]);
		String err6 = c.controllaPasswordMail(config[6], config[7]);
		String err7 = c.controllaUsernameMail(config[8]);
		String err8 = c.controllaUsername(config[9]);
		String err9 = c.controllaPorta(config[10]);
		String err10 = c.controllaUsername(config[11]);
		String err11 = c.controllaNomeAgenzia(config[12]);
		String err12 = c.controllaPassword(config[13],config[14]);
		String err13 = c.controllaIndirizzo(config[15]);
		String err14 = c.controllaFax(config[16]);
		String err15 = c.controllaTelefono(config[17]);
		String err16 = c.controllaDescrizione(config[18]);
		String err17 = c.controllaEmail(config[19]);
		//String err18 = c.stile(config[21]);
		if (err1.equals("") && err2.equals("") && err3.equals("") && err4.equals("") && err5.equals("") && err6.equals("") && err7.equals("") && err8.equals("") && err9.equals("") && err10.equals("") && err11.equals("") && err12.equals("") && err13.equals("") && err14.equals("") && err15.equals("") && err16.equals("") && err17.equals("") ){
			if (creaDB(config[0], config[1], config[2], config[10], config[9])){
				if(creaTabelle(config[0], config[1], config[2], config[10], config[9])){
					if(regioni(config[0], config[1], config[2], config[10], config[9])){
						if(province(config[0], config[1], config[2], config[10], config[9])){
							if(comuni(config[0], config[1], config[2], config[10], config[9])){
								if(queryAgenzia(config[0], config[1], config[2], config[10], config[9], config[12], config[13], config[11], config[15], config[16], config[19], config[20], Integer.parseInt(config[17]), config[18])){
									if(scrivi(config)){
										
									}else{
										ok.concat("errore nella scrittura del file di configurazione");
									}
								}else{
									ok.concat("errore nell'inserimento dei dati sull'agenzia");
								}
							}else{
								ok.concat("errore nella creazione dei comuni");
							}
			           }else{
			            	ok.concat("errore nell'inserimento delle provincie");
			            }
					}else{
						ok.concat("errore nell'inserimento delle regioni");
					}
				}else{
					ok.concat("errore nella creazione del database");
				}
			}else{
				ok.concat("errore nella connessione col database");
			}
		}else {
			ok.concat("errore nell'inserimento di qualche campo ");
		}
		return ok;
	}

	private boolean scrivi(String[] config) {
		try {
			Properties properties = new Properties();
			properties.setProperty("nomedb",config[0]);
			properties.setProperty("passworddb",config[2]);
			properties.setProperty("posizionedb",config[1]);
			properties.setProperty("usernamedb",config[9]);
			properties.setProperty("portadb",config[10]);
			properties.setProperty("serviziomail",config[4]);
			properties.setProperty("portamail",config[5]);
			properties.setProperty("usernamemail",config[8]);
			properties.setProperty("passwordmail",config[6]);
			properties.setProperty("stile",config[21]);
			File file = new File("config.properties");
			file.createNewFile();
			FileOutputStream fileOut = new FileOutputStream(file);
			properties.store(fileOut, "Configurazione");
			fileOut.close();
		} catch (FileNotFoundException e) {
			return false;
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	private boolean creaDB(String nome, String pos, String pass, String porta, String user) {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://"+pos+":"+porta,user,pass);
			try{
				java.sql.Statement st = con.createStatement();
				st.executeUpdate("CREATE DATABASE "+nome);
				
			}
			catch (SQLException s){
				return false;
			}
		}catch (Exception e){
			return false;
		}
		return true;
	}
	
	private boolean creaTabelle(String nome, String pos, String pass, String porta, String user){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://"+pos+":"+porta+"/"+nome,user,pass);
			try{
				java.sql.Statement st = con.createStatement();
				InputStream fstream = new FileInputStream("sql/Agezia.ddl");
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)
					st.executeUpdate(strLine);
				in.close();
			}catch (SQLException s){
				return false;
			}
		}catch (Exception e){
			return false;
		}
		return true;
	}
	
	private boolean regioni(String nome, String pos, String pass, String porta, String user){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://"+pos+":"+porta+"/"+nome,user,pass);
			try{
				java.sql.Statement st = con.createStatement();
				InputStream fstream = new FileInputStream("sql/regioni.sql");
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)
					st.executeUpdate(strLine);
				in.close();
			}catch (SQLException s){
				//return false;
			}
		}catch (Exception e){
			//return false;
		}
		return true;
	}
	
	private boolean province(String nome, String pos, String pass, String porta, String user){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://"+pos+":"+porta+"/"+nome,user,pass);
			try{
				java.sql.Statement st = con.createStatement();
				InputStream fstream = new FileInputStream("sql/province.sql");
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)
					st.executeUpdate(strLine);
				in.close();
			}catch (SQLException s){
				//return false;
			}
		}catch (Exception e){
			//return false;
		}
		return true;
	}
	
	private boolean comuni(String nome, String pos, String pass, String porta, String user){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://"+pos+":"+porta+"/"+nome,user,pass);
			try{
				java.sql.Statement st = con.createStatement();
				InputStream fstream = new FileInputStream("sql/comuni.sql");
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)
					st.executeUpdate(strLine);
				in.close();
			}catch (SQLException s){
				//return false;
			}
		}catch (Exception e){
			//return false;
		}
		return true;
	}

	private boolean queryAgenzia(String nome, String pos, String pass, String porta, String user,String nomeag, String passag, String userag, String ind, String fax, String mail, String logo, int tel, String desc) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://"+pos+":"+porta+"/"+nome,user,pass);
			java.sql.Statement st = con.createStatement();
			st.executeUpdate("INSERT INTO agenzia VALUES (1, '"+ind+"', '"+nomeag+"', '"+fax+"', '"+userag+"', '"+passag+"', '"+mail+"', '"+logo+"', "+tel+", '"+desc+"', 12)");
		} catch (SQLException e) {
			//return false;
			// TODO Auto-generated catch block
			
		} catch (ClassNotFoundException e) {
			//return false;
			// TODO Auto-generated catch block
			
		}
		return true;
	}

}
