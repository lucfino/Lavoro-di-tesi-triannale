package com.agenzia.immobiliare.server;

import org.orm.PersistentException;
import org.orm.PersistentSession;

import com.agenzia.immobiliare.client.AgenziaService;
import com.agenzia.immobiliare.client.entity.Agenzia;
import com.agenzia.immobiliare.server.orm.AgeziaPersistentManager;
import com.agenzia.immobiliare.server.orm.entity.AgenziaDAO;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

@SuppressWarnings("serial")
public class AgenziaServiceImpl extends RemoteServiceServlet implements AgenziaService{

	@Override
	public Agenzia carica() {
		Agenzia a = new Agenzia();
		try {
			Agenzia[] ag  = AgenziaDAO.listAgenziaByQuery(null, null);
			a = ag[0];
		} catch (PersistentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}

	@Override
	public boolean modifica(String ind, String nom, String fa, String user,
			String pass, String mail, String desc, int tel) {
		try {
			Agenzia ag = AgenziaDAO.loadAgenziaByORMID(1);
			ag.setIndirizzo(ind);
			ag.setNome(nom);
			ag.setFax(fa);
			ag.setUsername(user);
			ag.setPassword(pass);
			ag.setEmail(mail);
			ag.setDescrizione(desc);
			ag.setTelefono(tel);
			PersistentSession s = AgeziaPersistentManager.instance().getSession();
			s.beginTransaction();
			s.update(ag);
			s.getTransaction().commit();
		} catch (PersistentException e) {
			
			e.printStackTrace();
		}
		return true;
		
	}

	
	
	
	
	

}
