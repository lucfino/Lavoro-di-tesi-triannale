/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.server.orm.entity;

import org.orm.*;
import org.hibernate.Query;

import com.agenzia.immobiliare.client.entity.*;

import java.util.List;

public class GarageDAO {
	public static Garage loadGarageByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadGarageByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage getGarageByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getGarageByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadGarageByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage getGarageByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getGarageByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (Garage) session.load(com.agenzia.immobiliare.client.entity.Garage.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage getGarageByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (Garage) session.get(com.agenzia.immobiliare.client.entity.Garage.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Garage) session.load(com.agenzia.immobiliare.client.entity.Garage.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage getGarageByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Garage) session.get(com.agenzia.immobiliare.client.entity.Garage.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage[] listGarageByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listGarageByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage[] listGarageByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listGarageByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage[] listGarageByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Garage as Garage");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			List list = query.list();
			return (Garage[]) list.toArray(new Garage[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage[] listGarageByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Garage as Garage");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			List list = query.list();
			return (Garage[]) list.toArray(new Garage[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadGarageByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadGarageByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Garage[] garages = listGarageByQuery(session, condition, orderBy);
		if (garages != null && garages.length > 0)
			return garages[0];
		else
			return null;
	}
	
	public static Garage loadGarageByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Garage[] garages = listGarageByQuery(session, condition, orderBy, lockMode);
		if (garages != null && garages.length > 0)
			return garages[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateGarageByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateGarageByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateGarageByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateGarageByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateGarageByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Garage as Garage");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateGarageByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Garage as Garage");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage createGarage() {
		return new com.agenzia.immobiliare.client.entity.Garage();
	}
	
	public static boolean save(com.agenzia.immobiliare.client.entity.Garage garage) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().saveObject(garage);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(com.agenzia.immobiliare.client.entity.Garage garage) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().deleteObject(garage);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(com.agenzia.immobiliare.client.entity.Garage garage) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().refresh(garage);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(com.agenzia.immobiliare.client.entity.Garage garage) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().evict(garage);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Garage loadGarageByCriteria(GarageCriteria garageCriteria) {
		Garage[] garages = listGarageByCriteria(garageCriteria);
		if(garages == null || garages.length == 0) {
			return null;
		}
		return garages[0];
	}
	
	public static Garage[] listGarageByCriteria(GarageCriteria garageCriteria) {
		return garageCriteria.listGarage();
	}
}
