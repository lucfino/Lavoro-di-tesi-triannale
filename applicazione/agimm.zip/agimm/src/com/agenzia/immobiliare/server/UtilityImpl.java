package com.agenzia.immobiliare.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Properties;

import javax.servlet.http.HttpSession;

import org.orm.PersistentException;

import com.agenzia.immobiliare.client.Utility;
import com.agenzia.immobiliare.client.entity.Agenzia;
import com.agenzia.immobiliare.client.entity.EAnnuncio;
import com.agenzia.immobiliare.client.view.IVMapsAdapter;
import com.agenzia.immobiliare.server.orm.entity.AgenziaDAO;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

@SuppressWarnings("serial")
public class UtilityImpl extends RemoteServiceServlet implements Utility{

	@Override
	public String[] esiste(String path) {
		File f = new File(path);
		String [] conf = new String[19];
		setAdmin("control", "si", getSession());
		if (f.exists()){
			try {
				Agenzia[] ag = AgenziaDAO.listAgenziaByQuery(null, null);
				conf[0] = "esiste";
				conf[1] = ag[0].getNome();
				conf[2] = ag[0].getIndirizzo();
				conf[3] = ag[0].getEmail();
				conf[4] = ag[0].getFax();
				conf[5] = ag[0].getLogo();
				conf[6] = ag[0].getDescrizione();
				conf[7] = String.valueOf(ag[0].getTelefono());
				Properties pro = new Properties();
				pro.load(new FileInputStream("config.properties"));
				conf[8] = pro.getProperty("nomedb");
				conf[9] = pro.getProperty("posizionedb");
				conf[10] = pro.getProperty("passworddb");
				conf[11] = pro.getProperty("serviziomail");
				conf[12] = pro.getProperty("portamail");
				conf[13] = pro.getProperty("usernamemail");
				conf[14] = pro.getProperty("passwordmail");
				conf[15] = pro.getProperty("usernamedb");
				conf[16] = pro.getProperty("portadb");
				conf[17] = pro.getProperty("stile");
				conf[18] = pro.getProperty("maps");
			} catch (PersistentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			conf[0] = "";
		}
		return conf;
	}
	
	public String controlla(){
		String control = getAdmin("control", getSession());
		if (control == null){
			return "cookie non attivati";
		}
		return "";
	}

	@Override
	public boolean autentica(String user, String pass) {
		boolean aut = false;
		try {
			Agenzia ag = AgenziaDAO.loadAgenziaByORMID(1);
			if (ag.getUsername().equals(user) && ag.getPassword().equals(pass)){
				aut = true;
				setAdmin("admin", user, getSession());
			}
		} catch (PersistentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return aut;
	}

	@Override
	public boolean loggato() {
		boolean log = false;
		String admin = getAdmin("admin", getSession());
		if (admin != null){
			log = true;
		}
		return log;
	}

	public void logout(){
		rimuovi("admin", getSession());
	}
	
	private HttpSession getSession(){
		return this.getThreadLocalRequest().getSession();
	}
	
	private String getAdmin(String chiave, HttpSession session){
		return (String)session.getAttribute(chiave);
	}
	
	private void setAdmin(String chiave, String valore, HttpSession session){
		session.setAttribute(chiave, valore);
	}
	
	public void rimuovi(String chiave, HttpSession session){
		session.removeAttribute(chiave);
	}
	
	@SuppressWarnings("unchecked")
	private LinkedList<EAnnuncio> getAnnuncio(String chiave, HttpSession session){
		return (LinkedList<EAnnuncio>) session.getAttribute(chiave);
	}
	
	private void setAnnuncio(String chiave, EAnnuncio ann, HttpSession session){
		LinkedList<EAnnuncio> lista = getAnnuncio(chiave, getSession());
		if (lista == null){
			lista = new LinkedList<EAnnuncio>();
		}else {
			if (!lista.contains(ann)){
				lista.add(ann);
			}
		}
		session.setAttribute(chiave, lista);
	}

	
	@Override
	public void salva(int id) {
		AnnuncioImpl ai = new AnnuncioImpl();
		EAnnuncio ann = ai.carica(id);
		setAnnuncio("lista", ann, getSession());
	}


	@Override
	public LinkedList<EAnnuncio> carica() {
		LinkedList<EAnnuncio> ann = getAnnuncio("lista", getSession());
		if (ann == null){
			ann = new LinkedList<EAnnuncio>();
		}
		return ann;
	}

	@Override
	public IVMapsAdapter carica(String name) {
		IVMapsAdapter mapsAdapter = null;
		try {
			mapsAdapter = (IVMapsAdapter) Class.forName("VMapsAdapter.java").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mapsAdapter;
	}
	
	

	
	
}
