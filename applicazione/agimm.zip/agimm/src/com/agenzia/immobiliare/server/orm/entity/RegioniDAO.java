/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.server.orm.entity;

import org.orm.*;
import org.hibernate.Query;

import com.agenzia.immobiliare.client.entity.*;

import java.util.List;

public class RegioniDAO {
	public static Regioni loadRegioniByORMID(int idregioni) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadRegioniByORMID(session, idregioni);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni getRegioniByORMID(int idregioni) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getRegioniByORMID(session, idregioni);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByORMID(int idregioni, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadRegioniByORMID(session, idregioni, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni getRegioniByORMID(int idregioni, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getRegioniByORMID(session, idregioni, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByORMID(PersistentSession session, int idregioni) throws PersistentException {
		try {
			return (Regioni) session.load(com.agenzia.immobiliare.client.entity.Regioni.class, new Integer(idregioni));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni getRegioniByORMID(PersistentSession session, int idregioni) throws PersistentException {
		try {
			return (Regioni) session.get(com.agenzia.immobiliare.client.entity.Regioni.class, new Integer(idregioni));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByORMID(PersistentSession session, int idregioni, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Regioni) session.load(com.agenzia.immobiliare.client.entity.Regioni.class, new Integer(idregioni), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni getRegioniByORMID(PersistentSession session, int idregioni, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Regioni) session.get(com.agenzia.immobiliare.client.entity.Regioni.class, new Integer(idregioni), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni[] listRegioniByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listRegioniByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni[] listRegioniByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listRegioniByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni[] listRegioniByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Regioni as Regioni");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			List list = query.list();
			return (Regioni[]) list.toArray(new Regioni[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni[] listRegioniByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Regioni as Regioni");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			List list = query.list();
			return (Regioni[]) list.toArray(new Regioni[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadRegioniByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadRegioniByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Regioni[] regionis = listRegioniByQuery(session, condition, orderBy);
		if (regionis != null && regionis.length > 0)
			return regionis[0];
		else
			return null;
	}
	
	public static Regioni loadRegioniByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Regioni[] regionis = listRegioniByQuery(session, condition, orderBy, lockMode);
		if (regionis != null && regionis.length > 0)
			return regionis[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateRegioniByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateRegioniByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateRegioniByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateRegioniByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateRegioniByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Regioni as Regioni");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateRegioniByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.Regioni as Regioni");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni createRegioni() {
		return new com.agenzia.immobiliare.client.entity.Regioni();
	}
	
	public static boolean save(com.agenzia.immobiliare.client.entity.Regioni regioni) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().saveObject(regioni);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(com.agenzia.immobiliare.client.entity.Regioni regioni) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().deleteObject(regioni);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(com.agenzia.immobiliare.client.entity.Regioni regioni) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().refresh(regioni);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(com.agenzia.immobiliare.client.entity.Regioni regioni) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().evict(regioni);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Regioni loadRegioniByCriteria(RegioniCriteria regioniCriteria) {
		Regioni[] regionis = listRegioniByCriteria(regioniCriteria);
		if(regionis == null || regionis.length == 0) {
			return null;
		}
		return regionis[0];
	}
	
	public static Regioni[] listRegioniByCriteria(RegioniCriteria regioniCriteria) {
		return regioniCriteria.listRegioni();
	}
}
