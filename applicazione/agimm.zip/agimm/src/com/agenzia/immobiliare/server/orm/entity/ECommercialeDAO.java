/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: DuKe TeAm
 * License Type: Purchased
 */
package com.agenzia.immobiliare.server.orm.entity;

import org.orm.*;
import org.hibernate.Query;

import com.agenzia.immobiliare.client.entity.*;

import java.util.List;

public class ECommercialeDAO {
	public static ECommerciale loadECommercialeByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadECommercialeByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale getECommercialeByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getECommercialeByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadECommercialeByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale getECommercialeByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return getECommercialeByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (ECommerciale) session.load(com.agenzia.immobiliare.client.entity.ECommerciale.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale getECommercialeByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (ECommerciale) session.get(com.agenzia.immobiliare.client.entity.ECommerciale.class, new Integer(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (ECommerciale) session.load(com.agenzia.immobiliare.client.entity.ECommerciale.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale getECommercialeByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (ECommerciale) session.get(com.agenzia.immobiliare.client.entity.ECommerciale.class, new Integer(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale[] listECommercialeByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listECommercialeByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale[] listECommercialeByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return listECommercialeByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale[] listECommercialeByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.ECommerciale as ECommerciale");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			List list = query.list();
			return (ECommerciale[]) list.toArray(new ECommerciale[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale[] listECommercialeByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.ECommerciale as ECommerciale");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			List list = query.list();
			return (ECommerciale[]) list.toArray(new ECommerciale[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadECommercialeByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return loadECommercialeByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		ECommerciale[] eCommerciales = listECommercialeByQuery(session, condition, orderBy);
		if (eCommerciales != null && eCommerciales.length > 0)
			return eCommerciales[0];
		else
			return null;
	}
	
	public static ECommerciale loadECommercialeByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		ECommerciale[] eCommerciales = listECommercialeByQuery(session, condition, orderBy, lockMode);
		if (eCommerciales != null && eCommerciales.length > 0)
			return eCommerciales[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateECommercialeByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateECommercialeByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateECommercialeByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession();
			return iterateECommercialeByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateECommercialeByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.ECommerciale as ECommerciale");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateECommercialeByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From com.agenzia.immobiliare.client.entity.ECommerciale as ECommerciale");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("this", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean save(com.agenzia.immobiliare.client.entity.ECommerciale eCommerciale) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().saveObject(eCommerciale);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(com.agenzia.immobiliare.client.entity.ECommerciale eCommerciale) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().deleteObject(eCommerciale);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(com.agenzia.immobiliare.client.entity.ECommerciale eCommerciale) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().refresh(eCommerciale);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(com.agenzia.immobiliare.client.entity.ECommerciale eCommerciale) throws PersistentException {
		try {
			com.agenzia.immobiliare.server.orm.AgeziaPersistentManager.instance().getSession().evict(eCommerciale);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static ECommerciale loadECommercialeByCriteria(ECommercialeCriteria eCommercialeCriteria) {
		ECommerciale[] eCommerciales = listECommercialeByCriteria(eCommercialeCriteria);
		if(eCommerciales == null || eCommerciales.length == 0) {
			return null;
		}
		return eCommerciales[0];
	}
	
	public static ECommerciale[] listECommercialeByCriteria(ECommercialeCriteria eCommercialeCriteria) {
		return eCommercialeCriteria.listECommerciale();
	}
}
